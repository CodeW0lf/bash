
DCP_Saved = {
	["fadeInTime"] = 0.3,
	["petOverlay"] = {
		1, -- [1]
		1, -- [2]
		1, -- [3]
	},
	["holdTime"] = 0,
	["fadeOutTime"] = 0.7,
	["maxAlpha"] = 0.7,
	["x"] = 683.626708984375,
	["iconSize"] = 59.5857429504395,
	["animScale"] = 1.5,
	["ignoredSpells"] = "",
	["y"] = 354.453330993652,
}
