
MasterPlanAG = {
	["Draenor"] = {
		["Wolfranger"] = {
			["faction"] = "Alliance",
			["summary"] = {
				["ti3"] = 128391,
				["tt1"] = 1474960896,
				["tt3"] = true,
				["inProgress"] = {
					[314] = 1475064855,
					[200] = 1475041455,
					[723] = 1450945796,
				},
				["ti1"] = 118529,
			},
			["curOil"] = 245,
			["cacheSize"] = 1000,
			["lastCacheTime"] = 1450944757,
			["curRes"] = 9570,
			["class"] = "HUNTER",
		},
		["Wolfspirit"] = {
			["class"] = "SHAMAN",
			["faction"] = "Alliance",
		},
		["Snipewolf"] = {
		},
		["Wolfform"] = {
			["summary"] = {
				["ti2"] = 122484,
				["inProgress"] = {
					[402] = 1474979431,
					[200] = 1474963232,
					[730] = 1474351523,
					[173] = 1474959632,
					[429] = 1474986633,
					[668] = 1474986632,
					[663] = 1474972234,
				},
				["ti3"] = 128391,
				["tt1"] = 1474181849,
				["ti1"] = 118529,
				["tt3"] = true,
				["tt2"] = 1474960468,
			},
			["curOil"] = 365,
			["class"] = "DRUID",
			["lastCacheTime"] = 1472618307,
			["curRes"] = 9835,
			["faction"] = "Alliance",
		},
		["Wolfsteel"] = {
			["faction"] = "Alliance",
			["class"] = "ROGUE",
		},
		["Magewolf"] = {
		},
		["Rynarch"] = {
			["class"] = "WARRIOR",
			["faction"] = "Alliance",
		},
		["Wolfblayde"] = {
			["class"] = "WARRIOR",
			["faction"] = "Alliance",
		},
		["Wolfmage"] = {
		},
		["Rhaas"] = {
			["faction"] = "Alliance",
			["class"] = "PALADIN",
		},
	},
	["Wyrmrest Accord"] = {
		["Rynarch"] = {
			["class"] = "WARRIOR",
			["faction"] = "Alliance",
		},
		["Zekin"] = {
			["class"] = "DRUID",
			["faction"] = "Alliance",
		},
		["Dreadwolf"] = {
			["faction"] = "Alliance",
			["class"] = "DEATHKNIGHT",
		},
		["Wolfpet"] = {
			["class"] = "HUNTER",
			["faction"] = "Alliance",
		},
		["Kyndethria"] = {
			["class"] = "DEMONHUNTER",
			["faction"] = "Alliance",
		},
		["Wolfform"] = {
			["class"] = "DRUID",
			["faction"] = "Alliance",
		},
		["Wolform"] = {
			["class"] = "DRUID",
			["faction"] = "Alliance",
		},
	},
	["Bloodhoof"] = {
		["Nayuka"] = {
		},
		["Wolfglaive"] = {
			["class"] = "DEMONHUNTER",
			["faction"] = "Horde",
		},
		["Dreadwolf"] = {
		},
		["Cowadinn"] = {
		},
		["Kalixx"] = {
			["lastCacheTime"] = 1428737230,
		},
		["Arcanewolf"] = {
			["curOil"] = 75,
			["faction"] = "Horde",
			["class"] = "MAGE",
			["curRes"] = 6128,
			["lastCacheTime"] = 1473565982,
		},
		["Taliowolf"] = {
			["summary"] = {
				["ti2"] = 122484,
				["inProgress"] = {
					[175] = 1475438580,
					[176] = 1475438580,
					[126] = 1475443081,
					[266] = 1475450281,
					[260] = 1475450283,
					[310] = 1475441282,
					[498] = 1475453882,
				},
				["ti3"] = 128391,
				["tt1"] = 1475217148,
				["ti1"] = 118529,
				["tt3"] = true,
				["tt2"] = 1474615129,
			},
			["faction"] = "Horde",
			["class"] = "PALADIN",
			["lastCacheTime"] = 1475434911,
			["curRes"] = 7657,
			["curOil"] = 775,
		},
		["Linzzern"] = {
		},
		["Eiag"] = {
		},
		["Zenpaw"] = {
			["summary"] = {
				["inProgress"] = {
					[189] = 1475564889,
					[186] = 1475565790,
					[667] = 1475576590,
					[380] = 1475569391,
					[177] = 1475564891,
					[358] = 1475598192,
					[464] = 1475583793,
					[214] = 1475565789,
				},
			},
			["curOil"] = 855,
			["class"] = "MONK",
			["lastCacheTime"] = 1475562156,
			["curRes"] = 8613,
			["faction"] = "Horde",
		},
		["Necress"] = {
			["summary"] = {
				["tt2"] = 1475383334,
				["tt3"] = true,
				["ti1"] = 118529,
				["tt1"] = 1475131458,
				["ti3"] = 128391,
				["inProgress"] = {
					[395] = 1475763461,
					[667] = 1475749062,
					[663] = 1475749061,
					[678] = 1475777862,
					[428] = 1475749063,
					[204] = 1475737361,
					[381] = 1475770663,
				},
				["ti2"] = 122484,
			},
			["curOil"] = 760,
			["faction"] = "Horde",
			["class"] = "WARLOCK",
			["curRes"] = 10000,
			["lastCacheTime"] = 1475734675,
		},
		["Primalwolf"] = {
			["summary"] = {
				["inProgress"] = {
					[663] = 1474025738,
					[467] = 1474025737,
					[336] = 1474029337,
					[624] = 1448448701,
					[107] = 1474047338,
				},
			},
			["curOil"] = 255,
			["faction"] = "Horde",
			["lastCacheTime"] = 1474011303,
			["curRes"] = 5948,
			["class"] = "SHAMAN",
		},
		["Noxwolf"] = {
			["summary"] = {
				["ti2"] = 122484,
				["inProgress"] = {
					[677] = 1475597140,
					[427] = 1475575541,
					[667] = 1475575541,
					[676] = 1475589942,
					[685] = 1475582742,
					[202] = 1475567890,
					[359] = 1475597143,
					[316] = 1475589943,
				},
				["ti3"] = 128391,
				["tt1"] = 1475564057,
				["ti1"] = 118529,
				["tt3"] = 1474347499,
				["tt2"] = 1475564058,
			},
			["faction"] = "Horde",
			["class"] = "DEATHKNIGHT",
			["lastCacheTime"] = 1475561266,
			["curRes"] = 10000,
			["curOil"] = 10,
		},
		["Starrwolf"] = {
			["class"] = "DRUID",
			["faction"] = "Horde",
		},
		["Xeonwolf"] = {
			["summary"] = {
				["inProgress"] = {
					[144] = 1475565661,
					[363] = 1475572862,
					[221] = 1475564763,
					[206] = 1475567462,
				},
			},
			["faction"] = "Horde",
			["lastCacheTime"] = 1475562049,
			["curRes"] = 2426,
			["class"] = "ROGUE",
		},
		["Eruswolf"] = {
			["lastCacheTime"] = 1481610581,
			["recruitTime"] = 1472188727,
			["summary"] = {
				["tt2"] = 1480497203,
				["tt3"] = 1472790682,
				["tt1"] = 1480568918,
				["ti1"] = 118529,
				["ti3"] = 128391,
				["inProgress"] = {
					[674] = 1481639364,
					[335] = 1481646564,
					[671] = 1481639365,
					[316] = 1481639365,
					[429] = 1481624966,
					[675] = 1481639366,
				},
				["ti2"] = 122484,
			},
			["curOil"] = 295,
			["class"] = "PRIEST",
			["curRes"] = 7138,
			["faction"] = "Horde",
		},
		["Zariimi"] = {
		},
	},
	["IgnoreRewards"] = {
	},
}
