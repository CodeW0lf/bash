
DBT_AllPersistentOptions = {
	["Default"] = {
		["DBM"] = {
			["HugeTimerPoint"] = "CENTER",
			["TimerPoint"] = "TOPRIGHT",
			["TimerX"] = -223.000015258789,
			["HugeTimerX"] = 0,
			["TimerY"] = -260,
			["HugeTimerY"] = -120,
		},
	},
	["BenikUI"] = {
		["DBM"] = {
			["FontSize"] = 12,
			["TimerPoint"] = "TOPRIGHT",
			["Scale"] = 1,
			["TimerY"] = -260,
			["Font"] = "Interface\\AddOns\\ElvUI_BenikUI\\media\\fonts\\PROTOTYPE.TTF",
			["HugeScale"] = 1,
			["TimerX"] = -223.000015258789,
			["HugeTimerX"] = 0,
			["HugeTimerY"] = -120,
			["HugeTimerPoint"] = "CENTER",
			["Texture"] = "Interface\\AddOns\\ElvUI_BenikUI\\media\\textures\\Flat.tga",
		},
	},
}
