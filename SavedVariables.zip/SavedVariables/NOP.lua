
NewOpenablesProfile = {
	["char"] = {
		["Dreadwolf - Wyrmrest Accord"] = {
			["questBarID"] = 35797,
		},
		["Noxwolf - Bloodhoof"] = {
			["questBarID"] = 129161,
		},
		["Rhaas - Draenor"] = {
			["questBarID"] = 24132,
		},
		["Taliowolf - Bloodhoof"] = {
			["questBarID"] = 139882,
		},
		["Necress - Bloodhoof"] = {
			["questBarID"] = 136970,
		},
		["Wolfform - Draenor"] = {
			["questBarID"] = 133941,
		},
		["Wolform - Wyrmrest Accord"] = {
			["questBarID"] = 49202,
		},
		["Eruswolf - Bloodhoof"] = {
			["questBarID"] = 142401,
		},
		["Zenpaw - Bloodhoof"] = {
			["questBarID"] = 130074,
		},
	},
	["profileKeys"] = {
		["Kyndethria - Wyrmrest Accord"] = "Default",
		["Wolfar - Draenor"] = "Default",
		["Taliowolf - Bloodhoof"] = "Default",
		["Wolfranger - Draenor"] = "Default",
		["Wolfblayde - Draenor"] = "Default",
		["Wolform - Wyrmrest Accord"] = "Default",
		["Arcanewolf - Bloodhoof"] = "Default",
		["Wolfform - Wyrmrest Accord"] = "Default",
		["Wolfsteel - Draenor"] = "Default",
		["Dreadwolf - Wyrmrest Accord"] = "Default",
		["Rynarch - Wyrmrest Accord"] = "Default",
		["Noxwolf - Bloodhoof"] = "Default",
		["Rhaas - Draenor"] = "Default",
		["Rynarch - Draenor"] = "Default",
		["Kyndeathria - Draenor"] = "Default",
		["Necress - Bloodhoof"] = "Default",
		["Wolfform - Draenor"] = "Default",
		["Wolfspirit - Draenor"] = "Default",
		["Zenpaw - Bloodhoof"] = "Default",
		["Eruswolf - Bloodhoof"] = "Default",
		["Primalwolf - Bloodhoof"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["button"] = {
				"BOTTOMLEFT", -- [1]
				"UIParent", -- [2]
				"BOTTOMLEFT", -- [3]
				387.500823974609, -- [4]
				179.16716003418, -- [5]
			},
			["T_BLACKLIST"] = {
				[0] = true,
				[141655] = true,
			},
			["backdrop"] = false,
			["qb"] = {
				"TOPLEFT", -- [1]
				"UIParrent", -- [2]
				"TOPLEFT", -- [3]
			},
			["version"] = "|cFFFFFFFF07.02 11.12.2016 use |cFFFF00FF/nop|cFFFFFFFF",
		},
	},
}
