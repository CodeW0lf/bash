
BPBID_Options = {
	["ManualChange"] = "r134",
	["BattleFontFix"] = false,
	["Breedtip"] = {
		["Current"] = true,
		["Possible"] = true,
		["SpeciesBase"] = false,
		["CurrentStats25"] = true,
		["CurrentStats25Rare"] = true,
		["AllStats25Rare"] = true,
		["CurrentStats"] = false,
		["AllStats"] = false,
		["AllStats25"] = true,
	},
	["format"] = 3,
	["Tooltips"] = {
		["Enabled"] = true,
		["FBPT"] = true,
		["PJT"] = true,
		["BPT"] = true,
		["BattleTooltip"] = true,
	},
	["Names"] = {
		["HSFUpdateRarity"] = true,
		["PJT"] = true,
		["FBPT"] = true,
		["PJTRarity"] = false,
		["PrimaryBattle"] = true,
		["HSFUpdate"] = true,
		["BPT"] = true,
		["BattleTooltip"] = true,
	},
}
