
dbOHC = {
	["char"] = {
		["Dreadwolf - Wyrmrest Accord"] = {
			["firstun"] = false,
		},
		["Rynarch - Wyrmrest Accord"] = {
			["firstun"] = false,
		},
		["Noxwolf - Bloodhoof"] = {
			["firstun"] = false,
		},
		["Necress - Bloodhoof"] = {
			["firstun"] = false,
		},
		["Wolfform - Draenor"] = {
			["firstun"] = false,
		},
		["Wolfblayde - Draenor"] = {
			["firstun"] = false,
		},
		["Eruswolf - Bloodhoof"] = {
			["firstun"] = false,
		},
		["Zenpaw - Bloodhoof"] = {
			["firstun"] = false,
		},
		["Wolfform - Wyrmrest Accord"] = {
			["firstun"] = false,
		},
		["Kyndethria - Wyrmrest Accord"] = {
			["firstun"] = false,
		},
	},
	["profileKeys"] = {
		["Dreadwolf - Wyrmrest Accord"] = "Default",
		["Rynarch - Wyrmrest Accord"] = "Default",
		["Noxwolf - Bloodhoof"] = "Default",
		["Necress - Bloodhoof"] = "Default",
		["Wolfform - Draenor"] = "Default",
		["Wolfblayde - Draenor"] = "Default",
		["Eruswolf - Bloodhoof"] = "Default",
		["Zenpaw - Bloodhoof"] = "Default",
		["Wolfform - Wyrmrest Accord"] = "Default",
		["Kyndethria - Wyrmrest Accord"] = "Default",
	},
	["global"] = {
		["warn01_seen"] = 0,
		["firstrun"] = false,
	},
	["profiles"] = {
		["Default"] = {
			["toggles"] = {
				["SAVETROOPS"] = true,
				["MAKEITVERYQUICK"] = false,
				["MAKEITQUICK"] = false,
				["MOVEPANEL"] = false,
				["MAXIMIZEXP"] = true,
				["SPARE"] = true,
				["TROOPALERT"] = true,
			},
			["showmenu"] = true,
		},
	},
}
