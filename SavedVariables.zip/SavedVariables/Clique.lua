
CliqueDB = nil
CliqueDB3 = {
	["char"] = {
		["Xeonwolf - Bloodhoof"] = {
			["alerthidden"] = true,
		},
		["Taliowolf - Bloodhoof"] = {
			["alerthidden"] = true,
		},
		["Wolfranger - Draenor"] = {
			["alerthidden"] = true,
		},
		["Primalwolf - Bloodhoof"] = {
			["alerthidden"] = true,
		},
		["Wolfform - Draenor"] = {
			["spec1_profileKey"] = "Wolfform - Draenor",
			["specswap"] = true,
			["downclick"] = false,
			["fastooc"] = false,
			["spec4_profileKey"] = "Wolfform - Healz",
			["alerthidden"] = true,
			["spec3_profileKey"] = "Wolfform - Draenor",
			["spec2_profileKey"] = "Wolfform - Draenor",
		},
		["Wolfspirit - Draenor"] = {
			["alerthidden"] = true,
		},
		["Dreadwolf - Draenor"] = {
			["alerthidden"] = true,
		},
		["Eruswolf - Bloodhoof"] = {
			["spec1_profileKey"] = "Eruswolf - Disc",
			["sec_profileKey"] = "Eruswolf - Bloodhoof",
			["fastooc"] = false,
			["blacklist"] = {
				["TargetFrame"] = true,
				["PlayerFrame"] = true,
			},
			["specswap"] = true,
			["downclick"] = false,
			["pri_profileKey"] = "Eruswolf - Bloodhoof",
			["spec3_profileKey"] = "Eruswolf - Shadow",
			["spec2_profileKey"] = "Eruswolf - Bloodhoof",
			["alerthidden"] = true,
		},
		["Zenpaw - Bloodhoof"] = {
			["alerthidden"] = true,
		},
		["Wolfform - Wyrmrest Accord"] = {
			["spec1_profileKey"] = "Wolfform - Draenor",
			["specswap"] = true,
			["downclick"] = false,
			["alerthidden"] = true,
			["spec4_profileKey"] = "Wolfform - Healz",
			["spec3_profileKey"] = "Wolfform - Draenor",
			["spec2_profileKey"] = "Wolfform - Draenor",
			["fastooc"] = false,
		},
		["Noxwolf - Bloodhoof"] = {
			["alerthidden"] = true,
		},
	},
	["profileKeys"] = {
		["Kyndethria - Wyrmrest Accord"] = "Kyndethria - Wyrmrest Accord",
		["Taliowolf - Bloodhoof"] = "Taliowolf - Bloodhoof",
		["Magewolf - Draenor"] = "Magewolf - Draenor",
		["Zekin - Wyrmrest Accord"] = "Zekin - Wyrmrest Accord",
		["Wolfpet - Wyrmrest Accord"] = "Wolfpet - Wyrmrest Accord",
		["Wolfform - Wyrmrest Accord"] = "Wolfform - Healz",
		["Wolfglaive - Bloodhoof"] = "Wolfglaive - Bloodhoof",
		["Zariimi - Bloodhoof"] = "Zariimi - Bloodhoof",
		["Rynarch - Draenor"] = "Rynarch - Draenor",
		["Armawolf - Bloodhoof"] = "Armawolf - Bloodhoof",
		["Wolfspirit - Draenor"] = "Wolfspirit - Draenor",
		["Zenpaw - Bloodhoof"] = "Zenpaw - Bloodhoof",
		["Kalixx - Bloodhoof"] = "Kalixx - Bloodhoof",
		["Dreadwolf - Bloodhoof"] = "Dreadwolf - Bloodhoof",
		["Wolfar - Draenor"] = "Wolfar - Draenor",
		["Wolfcaster - Draenor"] = "Wolfcaster - Draenor",
		["Wolfranger - Draenor"] = "Wolfranger - Draenor",
		["Primalwolf - Bloodhoof"] = "Primalwolf - Bloodhoof",
		["Wolform - Wyrmrest Accord"] = "Wolform - Wyrmrest Accord",
		["Arcanewolf - Bloodhoof"] = "Arcanewolf - Bloodhoof",
		["Nayuka - Bloodhoof"] = "Nayuka - Bloodhoof",
		["Wolfblayde - Draenor"] = "Wolfblayde - Draenor",
		["Wolfsteel - Draenor"] = "Wolfsteel - Draenor",
		["Dreadwolf - Wyrmrest Accord"] = "Dreadwolf - Wyrmrest Accord",
		["Rynarch - Wyrmrest Accord"] = "Rynarch - Wyrmrest Accord",
		["Noxwolf - Bloodhoof"] = "Noxwolf - Bloodhoof",
		["Snipewolf - Draenor"] = "Snipewolf - Draenor",
		["Cowadinn - Bloodhoof"] = "Cowadinn - Bloodhoof",
		["Kyndeathria - Draenor"] = "Kyndeathria - Draenor",
		["Xeonwolf - Bloodhoof"] = "Xeonwolf - Bloodhoof",
		["Eiag - Bloodhoof"] = "Eiag - Bloodhoof",
		["Dreadwolf - Draenor"] = "Dreadwolf - Draenor",
		["Wolfform - Draenor"] = "Wolfform - Healz",
		["Wolfmage - Draenor"] = "Wolfmage - Draenor",
		["Linzzern - Bloodhoof"] = "Linzzern - Bloodhoof",
		["Eruswolf - Bloodhoof"] = "Eruswolf - Bloodhoof",
		["Rhaas - Draenor"] = "Rhaas - Draenor",
		["Necress - Bloodhoof"] = "Necress - Bloodhoof",
		["Starrwolf - Bloodhoof"] = "Starrwolf - Bloodhoof",
	},
	["profiles"] = {
		["Kyndethria - Wyrmrest Accord"] = {
			["bindings"] = {
				{
					["type"] = "target",
					["sets"] = {
						["default"] = true,
					},
					["key"] = "BUTTON1",
					["unit"] = "mouseover",
				}, -- [1]
				{
					["type"] = "menu",
					["key"] = "BUTTON2",
					["sets"] = {
						["default"] = true,
					},
				}, -- [2]
			},
		},
		["Eruswolf - Shadow"] = {
			["bindings"] = {
				{
					["sets"] = {
						["default"] = true,
					},
					["type"] = "target",
					["key"] = "BUTTON1",
					["unit"] = "mouseover",
				}, -- [1]
				{
					["type"] = "menu",
					["key"] = "BUTTON2",
					["sets"] = {
						["default"] = true,
					},
				}, -- [2]
				{
					["spell"] = "Dispersion",
					["key"] = "BUTTON4",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 237563,
					["type"] = "spell",
				}, -- [3]
				{
					["spell"] = "Power Word: Shield",
					["key"] = "SHIFT-BUTTON2",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 135940,
					["type"] = "spell",
				}, -- [4]
				{
					["spell"] = "Shadow Mend",
					["key"] = "SHIFT-BUTTON1",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 136202,
					["type"] = "spell",
				}, -- [5]
			},
		},
		["Taliowolf - Bloodhoof"] = {
			["bindings"] = {
				{
					["spell"] = "Holy Shock",
					["key"] = "SHIFT-BUTTON1",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 135972,
					["type"] = "spell",
				}, -- [1]
				{
					["spell"] = "Cleanse",
					["key"] = "BUTTON3",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 135949,
					["type"] = "spell",
				}, -- [2]
				{
					["spell"] = "Bestow Faith",
					["key"] = "BUTTON4",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 236249,
					["type"] = "spell",
				}, -- [3]
				{
					["spell"] = "Blessing of Protection",
					["key"] = "SHIFT-BUTTON4",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 135964,
					["type"] = "spell",
				}, -- [4]
				{
					["spell"] = "Light of Dawn",
					["key"] = "SHIFT-BUTTON3",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 461859,
					["type"] = "spell",
				}, -- [5]
				{
					["spell"] = "Holy Light",
					["key"] = "BUTTON2",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 135981,
					["type"] = "spell",
				}, -- [6]
				{
					["type"] = "target",
					["key"] = "CTRL-BUTTON1",
					["sets"] = {
						["default"] = true,
					},
				}, -- [7]
				{
					["type"] = "menu",
					["key"] = "CTRL-BUTTON2",
					["sets"] = {
						["default"] = true,
					},
				}, -- [8]
				{
					["spell"] = "Light of the Martyr",
					["key"] = "SHIFT-BUTTON2",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 1360762,
					["type"] = "spell",
				}, -- [9]
				{
					["spell"] = "Flash of Light",
					["key"] = "BUTTON1",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 135907,
					["type"] = "spell",
				}, -- [10]
				{
					["spell"] = "Lay on Hands",
					["key"] = "SHIFT-BUTTON5",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 135928,
					["type"] = "spell",
				}, -- [11]
				{
					["spell"] = "Beacon of Light",
					["key"] = "BUTTON5",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 236247,
					["type"] = "spell",
				}, -- [12]
			},
		},
		["Magewolf - Draenor"] = {
			["bindings"] = {
				{
					["sets"] = {
						["default"] = true,
					},
					["type"] = "target",
					["key"] = "BUTTON1",
					["unit"] = "mouseover",
				}, -- [1]
				{
					["type"] = "menu",
					["key"] = "BUTTON2",
					["sets"] = {
						["default"] = true,
					},
				}, -- [2]
			},
		},
		["Zekin - Wyrmrest Accord"] = {
			["bindings"] = {
				{
					["sets"] = {
						["default"] = true,
					},
					["type"] = "target",
					["key"] = "BUTTON1",
					["unit"] = "mouseover",
				}, -- [1]
				{
					["type"] = "menu",
					["key"] = "BUTTON2",
					["sets"] = {
						["default"] = true,
					},
				}, -- [2]
			},
		},
		["Wolfpet - Wyrmrest Accord"] = {
			["bindings"] = {
				{
					["type"] = "target",
					["sets"] = {
						["default"] = true,
					},
					["key"] = "BUTTON1",
					["unit"] = "mouseover",
				}, -- [1]
				{
					["type"] = "menu",
					["key"] = "BUTTON2",
					["sets"] = {
						["default"] = true,
					},
				}, -- [2]
			},
		},
		["Wolfform - Wyrmrest Accord"] = {
			["bindings"] = {
				{
					["type"] = "target",
					["sets"] = {
						["default"] = true,
					},
					["key"] = "BUTTON1",
					["unit"] = "mouseover",
				}, -- [1]
				{
					["type"] = "menu",
					["key"] = "BUTTON2",
					["sets"] = {
						["default"] = true,
					},
				}, -- [2]
			},
		},
		["Wolfglaive - Bloodhoof"] = {
			["bindings"] = {
				{
					["type"] = "target",
					["sets"] = {
						["default"] = true,
					},
					["key"] = "BUTTON1",
					["unit"] = "mouseover",
				}, -- [1]
				{
					["type"] = "menu",
					["key"] = "BUTTON2",
					["sets"] = {
						["default"] = true,
					},
				}, -- [2]
			},
		},
		["Zariimi - Bloodhoof"] = {
			["bindings"] = {
				{
					["type"] = "target",
					["sets"] = {
						["default"] = true,
					},
					["key"] = "BUTTON1",
					["unit"] = "mouseover",
				}, -- [1]
				{
					["type"] = "menu",
					["key"] = "BUTTON2",
					["sets"] = {
						["default"] = true,
					},
				}, -- [2]
			},
		},
		["Starrwolf - Bloodhoof"] = {
			["bindings"] = {
				{
					["sets"] = {
						["default"] = true,
					},
					["type"] = "target",
					["key"] = "BUTTON1",
					["unit"] = "mouseover",
				}, -- [1]
				{
					["type"] = "menu",
					["key"] = "BUTTON2",
					["sets"] = {
						["default"] = true,
					},
				}, -- [2]
			},
		},
		["Wolfform - Healz"] = {
			["bindings"] = {
				{
					["spell"] = "Healing Touch",
					["key"] = "BUTTON2",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 136041,
					["type"] = "spell",
				}, -- [1]
				{
					["spell"] = "Rejuvenation",
					["key"] = "BUTTON1",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 136081,
					["type"] = "spell",
				}, -- [2]
				{
					["spell"] = "Nature's Cure",
					["key"] = "SHIFT-BUTTON3",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 236288,
					["type"] = "spell",
				}, -- [3]
				{
					["spell"] = "Regrowth",
					["key"] = "SHIFT-BUTTON2",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 136085,
					["type"] = "spell",
				}, -- [4]
				{
					["spell"] = "Ironbark",
					["key"] = "SHIFT-BUTTON4",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 572025,
					["type"] = "spell",
				}, -- [5]
				{
					["spell"] = "Lifebloom",
					["key"] = "SHIFT-BUTTON1",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 134206,
					["type"] = "spell",
				}, -- [6]
				{
					["type"] = "target",
					["key"] = "CTRL-BUTTON1",
					["sets"] = {
						["default"] = true,
					},
				}, -- [7]
				{
					["type"] = "menu",
					["key"] = "CTRL-BUTTON2",
					["sets"] = {
						["default"] = true,
					},
				}, -- [8]
				{
					["spell"] = "Swiftmend",
					["key"] = "BUTTON4",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 134914,
					["type"] = "spell",
				}, -- [9]
				{
					["spell"] = "Cenarion Ward",
					["key"] = "BUTTON5",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 132137,
					["type"] = "spell",
				}, -- [10]
				{
					["spell"] = "Wild Growth",
					["key"] = "BUTTON3",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 236153,
					["type"] = "spell",
				}, -- [11]
				{
					["spell"] = "Essence of G'Hanir",
					["key"] = "SHIFT-BUTTON5",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 1115592,
					["type"] = "spell",
				}, -- [12]
				{
					["spell"] = "Tranquility",
					["key"] = "ALT-BUTTON5",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 136107,
					["type"] = "spell",
				}, -- [13]
			},
		},
		["Wolfspirit - Draenor"] = {
			["bindings"] = {
				{
					["type"] = "target",
					["sets"] = {
						["default"] = true,
					},
					["key"] = "CTRL-BUTTON1",
					["unit"] = "mouseover",
				}, -- [1]
				{
					["spell"] = "Healing Surge",
					["key"] = "BUTTON1",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 136044,
					["type"] = "spell",
				}, -- [2]
				{
					["spell"] = "Purify Spirit",
					["key"] = "SHIFT-BUTTON3",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 236288,
					["type"] = "spell",
				}, -- [3]
				{
					["spell"] = "Riptide",
					["key"] = "BUTTON5",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 252995,
					["type"] = "spell",
				}, -- [4]
				{
					["spell"] = "Healing Wave",
					["key"] = "BUTTON2",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 136043,
					["type"] = "spell",
				}, -- [5]
				{
					["spell"] = "Chain Heal",
					["key"] = "BUTTON3",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 136042,
					["type"] = "spell",
				}, -- [6]
				{
					["spell"] = "Spiritwalker's Grace",
					["key"] = "SHIFT-BUTTON2",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 451170,
					["type"] = "spell",
				}, -- [7]
				{
					["spell"] = "Healing Stream Totem",
					["key"] = "BUTTON4",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 135127,
					["type"] = "spell",
				}, -- [8]
				{
					["spell"] = "Ancestral Guidance",
					["key"] = "SHIFT-BUTTON5",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 538564,
					["type"] = "spell",
				}, -- [9]
				{
					["spell"] = "Healing Tide Totem",
					["key"] = "SHIFT-BUTTON4",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 538569,
					["type"] = "spell",
				}, -- [10]
				{
					["type"] = "menu",
					["key"] = "CTRL-BUTTON2",
					["sets"] = {
						["default"] = true,
					},
				}, -- [11]
			},
		},
		["Zenpaw - Bloodhoof"] = {
			["bindings"] = {
				{
					["sets"] = {
						["default"] = true,
					},
					["type"] = "target",
					["key"] = "CTRL-BUTTON1",
					["unit"] = "mouseover",
				}, -- [1]
				{
					["type"] = "menu",
					["key"] = "CTRL-BUTTON2",
					["sets"] = {
						["default"] = true,
					},
				}, -- [2]
				{
					["spell"] = "Vivify",
					["key"] = "SHIFT-BUTTON2",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 1360980,
					["type"] = "spell",
				}, -- [3]
				{
					["spell"] = "Detox",
					["key"] = "SHIFT-BUTTON3",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 460692,
					["type"] = "spell",
				}, -- [4]
				{
					["spell"] = "Zen Pulse",
					["key"] = "SHIFT-BUTTON1",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 613397,
					["type"] = "spell",
				}, -- [5]
				{
					["spell"] = "Effuse",
					["key"] = "BUTTON1",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 1360977,
					["type"] = "spell",
				}, -- [6]
				{
					["spell"] = "Revival",
					["key"] = "SHIFT-BUTTON5",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 1020466,
					["type"] = "spell",
				}, -- [7]
				{
					["spell"] = "Life Cocoon",
					["key"] = "SHIFT-BUTTON4",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 627485,
					["type"] = "spell",
				}, -- [8]
				{
					["spell"] = "Enveloping Mist",
					["key"] = "BUTTON2",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 775461,
					["type"] = "spell",
				}, -- [9]
				{
					["spell"] = "Essence Font",
					["key"] = "BUTTON3",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 1360978,
					["type"] = "spell",
				}, -- [10]
				{
					["spell"] = "Renewing Mist",
					["key"] = "BUTTON4",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 627487,
					["type"] = "spell",
				}, -- [11]
				{
					["spell"] = "Sheilun's Gift",
					["key"] = "BUTTON5",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 1242282,
					["type"] = "spell",
				}, -- [12]
			},
		},
		["Kalixx - Bloodhoof"] = {
			["bindings"] = {
				{
					["type"] = "target",
					["sets"] = {
						["default"] = true,
					},
					["key"] = "BUTTON1",
					["unit"] = "mouseover",
				}, -- [1]
				{
					["type"] = "menu",
					["key"] = "BUTTON2",
					["sets"] = {
						["default"] = true,
					},
				}, -- [2]
			},
		},
		["Dreadwolf - Bloodhoof"] = {
			["bindings"] = {
				{
					["sets"] = {
						["default"] = true,
					},
					["type"] = "target",
					["key"] = "BUTTON1",
					["unit"] = "mouseover",
				}, -- [1]
				{
					["type"] = "menu",
					["key"] = "BUTTON2",
					["sets"] = {
						["default"] = true,
					},
				}, -- [2]
			},
		},
		["Wolfar - Draenor"] = {
			["bindings"] = {
				{
					["sets"] = {
						["default"] = true,
					},
					["type"] = "target",
					["key"] = "BUTTON1",
					["unit"] = "mouseover",
				}, -- [1]
				{
					["type"] = "menu",
					["key"] = "BUTTON2",
					["sets"] = {
						["default"] = true,
					},
				}, -- [2]
			},
		},
		["Wolfcaster - Draenor"] = {
			["bindings"] = {
				{
					["sets"] = {
						["default"] = true,
					},
					["type"] = "target",
					["key"] = "BUTTON1",
					["unit"] = "mouseover",
				}, -- [1]
				{
					["type"] = "menu",
					["key"] = "BUTTON2",
					["sets"] = {
						["default"] = true,
					},
				}, -- [2]
			},
		},
		["Wolfranger - Draenor"] = {
			["bindings"] = {
				{
					["sets"] = {
						["default"] = true,
					},
					["type"] = "target",
					["key"] = "BUTTON1",
					["unit"] = "mouseover",
				}, -- [1]
				{
					["type"] = "menu",
					["key"] = "BUTTON2",
					["sets"] = {
						["default"] = true,
					},
				}, -- [2]
				{
					["spell"] = "Misdirection",
					["key"] = "BUTTON4",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 132180,
					["type"] = "spell",
				}, -- [3]
				{
					["spell"] = "Fetch",
					["key"] = "BUTTON5",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 133718,
					["type"] = "spell",
				}, -- [4]
			},
		},
		["Primalwolf - Bloodhoof"] = {
			["bindings"] = {
				{
					["type"] = "target",
					["sets"] = {
						["default"] = true,
					},
					["key"] = "BUTTON1",
					["unit"] = "mouseover",
				}, -- [1]
				{
					["type"] = "menu",
					["key"] = "BUTTON2",
					["sets"] = {
						["default"] = true,
					},
				}, -- [2]
				{
					["spell"] = "Healing Surge",
					["key"] = "BUTTON4",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = "Interface\\Icons\\Spell_Nature_HealingWay",
					["type"] = "spell",
				}, -- [3]
			},
		},
		["Eruswolf - Bloodhoof"] = {
			["bindings"] = {
				{
					["spell"] = "Guardian Spirit",
					["key"] = "SHIFT-BUTTON4",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = "Interface\\Icons\\Spell_Holy_GuardianSpirit",
					["type"] = "spell",
				}, -- [1]
				{
					["spell"] = "Prayer of Mending",
					["key"] = "BUTTON4",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = "Interface\\Icons\\Spell_Holy_PrayerOfMendingtga",
					["type"] = "spell",
				}, -- [2]
				{
					["spell"] = "Prayer of Healing",
					["key"] = "BUTTON3",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = "Interface\\Icons\\Spell_Holy_PrayerOfHealing02",
					["type"] = "spell",
				}, -- [3]
				{
					["type"] = "menu",
					["key"] = "CTRL-BUTTON2",
					["sets"] = {
						["default"] = true,
					},
				}, -- [4]
				{
					["spell"] = "Flash Heal",
					["key"] = "BUTTON1",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = "Interface\\Icons\\Spell_Holy_FlashHeal",
					["type"] = "spell",
				}, -- [5]
				{
					["spell"] = "Renew",
					["key"] = "BUTTON5",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = "Interface\\Icons\\Spell_Holy_Renew",
					["type"] = "spell",
				}, -- [6]
				{
					["spell"] = "Purify",
					["key"] = "SHIFT-BUTTON3",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 135894,
					["type"] = "spell",
				}, -- [7]
				{
					["spell"] = "Heal",
					["key"] = "BUTTON2",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = "Interface\\Icons\\Spell_Holy_GreaterHeal",
					["type"] = "spell",
				}, -- [8]
				{
					["type"] = "target",
					["key"] = "CTRL-BUTTON1",
					["sets"] = {
						["default"] = true,
					},
				}, -- [9]
				{
					["spell"] = "Holy Word: Serenity",
					["key"] = "SHIFT-BUTTON2",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = "INTERFACE\\ICONS\\spell_holy_persuitofjustice",
					["type"] = "spell",
				}, -- [10]
				{
					["spell"] = "Leap of Faith",
					["key"] = "SHIFT-BUTTON5",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 463835,
					["type"] = "spell",
				}, -- [11]
				{
					["spell"] = "Light of T'uure",
					["key"] = "SHIFT-BUTTON1",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 1295540,
					["type"] = "spell",
				}, -- [12]
			},
		},
		["Wolform - Wyrmrest Accord"] = {
			["bindings"] = {
				{
					["sets"] = {
						["default"] = true,
					},
					["type"] = "target",
					["key"] = "BUTTON1",
					["unit"] = "mouseover",
				}, -- [1]
				{
					["type"] = "menu",
					["key"] = "BUTTON2",
					["sets"] = {
						["default"] = true,
					},
				}, -- [2]
			},
		},
		["Dreadwolf - Wyrmrest Accord"] = {
			["bindings"] = {
				{
					["sets"] = {
						["default"] = true,
					},
					["type"] = "target",
					["key"] = "BUTTON1",
					["unit"] = "mouseover",
				}, -- [1]
				{
					["type"] = "menu",
					["key"] = "BUTTON2",
					["sets"] = {
						["default"] = true,
					},
				}, -- [2]
			},
		},
		["Arcanewolf - Bloodhoof"] = {
			["bindings"] = {
				{
					["type"] = "target",
					["sets"] = {
						["default"] = true,
					},
					["key"] = "BUTTON1",
					["unit"] = "mouseover",
				}, -- [1]
				{
					["type"] = "menu",
					["key"] = "BUTTON2",
					["sets"] = {
						["default"] = true,
					},
				}, -- [2]
			},
		},
		["Nayuka - Bloodhoof"] = {
			["bindings"] = {
				{
					["sets"] = {
						["default"] = true,
					},
					["type"] = "target",
					["key"] = "BUTTON1",
					["unit"] = "mouseover",
				}, -- [1]
				{
					["type"] = "menu",
					["key"] = "BUTTON2",
					["sets"] = {
						["default"] = true,
					},
				}, -- [2]
			},
		},
		["Rhaas - Draenor"] = {
			["bindings"] = {
				{
					["sets"] = {
						["default"] = true,
					},
					["type"] = "target",
					["key"] = "BUTTON1",
					["unit"] = "mouseover",
				}, -- [1]
				{
					["type"] = "menu",
					["key"] = "BUTTON2",
					["sets"] = {
						["default"] = true,
					},
				}, -- [2]
			},
		},
		["Wolfsteel - Draenor"] = {
			["bindings"] = {
				{
					["sets"] = {
						["default"] = true,
					},
					["type"] = "target",
					["key"] = "BUTTON1",
					["unit"] = "mouseover",
				}, -- [1]
				{
					["type"] = "menu",
					["key"] = "BUTTON2",
					["sets"] = {
						["default"] = true,
					},
				}, -- [2]
			},
		},
		["Wolfblayde - Draenor"] = {
			["bindings"] = {
				{
					["sets"] = {
						["default"] = true,
					},
					["type"] = "target",
					["key"] = "BUTTON1",
					["unit"] = "mouseover",
				}, -- [1]
				{
					["type"] = "menu",
					["key"] = "BUTTON2",
					["sets"] = {
						["default"] = true,
					},
				}, -- [2]
			},
		},
		["Rynarch - Wyrmrest Accord"] = {
			["bindings"] = {
				{
					["type"] = "target",
					["sets"] = {
						["default"] = true,
					},
					["key"] = "BUTTON1",
					["unit"] = "mouseover",
				}, -- [1]
				{
					["type"] = "menu",
					["key"] = "BUTTON2",
					["sets"] = {
						["default"] = true,
					},
				}, -- [2]
			},
		},
		["Noxwolf - Bloodhoof"] = {
			["bindings"] = {
				{
					["type"] = "target",
					["sets"] = {
						["default"] = true,
					},
					["key"] = "BUTTON1",
					["unit"] = "mouseover",
				}, -- [1]
				{
					["type"] = "menu",
					["key"] = "BUTTON2",
					["sets"] = {
						["default"] = true,
					},
				}, -- [2]
			},
		},
		["Snipewolf - Draenor"] = {
			["bindings"] = {
				{
					["sets"] = {
						["default"] = true,
					},
					["type"] = "target",
					["key"] = "BUTTON1",
					["unit"] = "mouseover",
				}, -- [1]
				{
					["type"] = "menu",
					["key"] = "BUTTON2",
					["sets"] = {
						["default"] = true,
					},
				}, -- [2]
			},
		},
		["Cowadinn - Bloodhoof"] = {
			["bindings"] = {
				{
					["type"] = "target",
					["sets"] = {
						["default"] = true,
					},
					["key"] = "BUTTON1",
					["unit"] = "mouseover",
				}, -- [1]
				{
					["type"] = "menu",
					["key"] = "BUTTON2",
					["sets"] = {
						["default"] = true,
					},
				}, -- [2]
			},
		},
		["Kyndeathria - Draenor"] = {
			["bindings"] = {
				{
					["sets"] = {
						["default"] = true,
					},
					["type"] = "target",
					["key"] = "BUTTON1",
					["unit"] = "mouseover",
				}, -- [1]
				{
					["type"] = "menu",
					["key"] = "BUTTON2",
					["sets"] = {
						["default"] = true,
					},
				}, -- [2]
			},
		},
		["Dreadwolf - Draenor"] = {
			["bindings"] = {
				{
					["type"] = "target",
					["sets"] = {
						["default"] = true,
					},
					["key"] = "BUTTON1",
					["unit"] = "mouseover",
				}, -- [1]
				{
					["type"] = "menu",
					["key"] = "BUTTON2",
					["sets"] = {
						["default"] = true,
					},
				}, -- [2]
			},
		},
		["Eiag - Bloodhoof"] = {
			["bindings"] = {
				{
					["sets"] = {
						["default"] = true,
					},
					["type"] = "target",
					["key"] = "BUTTON1",
					["unit"] = "mouseover",
				}, -- [1]
				{
					["type"] = "menu",
					["key"] = "BUTTON2",
					["sets"] = {
						["default"] = true,
					},
				}, -- [2]
			},
		},
		["Eruswolf - Disc"] = {
			["bindings"] = {
				{
					["sets"] = {
						["default"] = true,
					},
					["type"] = "target",
					["key"] = "CTRL-BUTTON1",
					["unit"] = "mouseover",
				}, -- [1]
				{
					["spell"] = "Power Word: Radiance",
					["key"] = "BUTTON3",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 1386546,
					["type"] = "spell",
				}, -- [2]
				{
					["spell"] = "Plea",
					["key"] = "BUTTON1",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 135915,
					["type"] = "spell",
				}, -- [3]
				{
					["spell"] = "Rapture",
					["key"] = "BUTTON4",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 237548,
					["type"] = "spell",
				}, -- [4]
				{
					["type"] = "menu",
					["key"] = "CTRL-BUTTON2",
					["sets"] = {
						["default"] = true,
					},
				}, -- [5]
				{
					["spell"] = "Power Word: Shield",
					["key"] = "SHIFT-BUTTON2",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 135940,
					["type"] = "spell",
				}, -- [6]
				{
					["spell"] = "Purify",
					["key"] = "SHIFT-BUTTON3",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 135894,
					["type"] = "spell",
				}, -- [7]
				{
					["spell"] = "Leap of Faith",
					["key"] = "SHIFT-BUTTON5",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 463835,
					["type"] = "spell",
				}, -- [8]
				{
					["spell"] = "Shadow Mend",
					["key"] = "BUTTON2",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 136202,
					["type"] = "spell",
				}, -- [9]
				{
					["spell"] = "Pain Suppression",
					["key"] = "SHIFT-BUTTON4",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 135936,
					["type"] = "spell",
				}, -- [10]
			},
		},
		["Wolfform - Draenor"] = {
			["bindings"] = {
				{
					["sets"] = {
						["default"] = true,
					},
					["type"] = "target",
					["key"] = "BUTTON1",
					["unit"] = "mouseover",
				}, -- [1]
				{
					["spell"] = "Swiftmend",
					["key"] = "BUTTON4",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 134914,
					["type"] = "spell",
				}, -- [2]
				{
					["spell"] = "Rejuvenation",
					["key"] = "SHIFT-BUTTON1",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 136081,
					["type"] = "spell",
				}, -- [3]
				{
					["type"] = "menu",
					["key"] = "BUTTON2",
					["sets"] = {
						["default"] = true,
					},
				}, -- [4]
				{
					["spell"] = "Regrowth",
					["key"] = "SHIFT-BUTTON2",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 136085,
					["type"] = "spell",
				}, -- [5]
				{
					["spell"] = "Survival Instincts",
					["key"] = "SHIFT-BUTTON4",
					["sets"] = {
						["default"] = true,
					},
					["icon"] = 236169,
					["type"] = "spell",
				}, -- [6]
			},
		},
		["Wolfmage - Draenor"] = {
			["bindings"] = {
				{
					["sets"] = {
						["default"] = true,
					},
					["type"] = "target",
					["key"] = "BUTTON1",
					["unit"] = "mouseover",
				}, -- [1]
				{
					["type"] = "menu",
					["key"] = "BUTTON2",
					["sets"] = {
						["default"] = true,
					},
				}, -- [2]
			},
		},
		["Linzzern - Bloodhoof"] = {
			["bindings"] = {
				{
					["sets"] = {
						["default"] = true,
					},
					["type"] = "target",
					["key"] = "BUTTON1",
					["unit"] = "mouseover",
				}, -- [1]
				{
					["type"] = "menu",
					["key"] = "BUTTON2",
					["sets"] = {
						["default"] = true,
					},
				}, -- [2]
			},
		},
		["Xeonwolf - Bloodhoof"] = {
			["bindings"] = {
				{
					["sets"] = {
						["default"] = true,
					},
					["type"] = "target",
					["key"] = "BUTTON1",
					["unit"] = "mouseover",
				}, -- [1]
				{
					["type"] = "menu",
					["key"] = "BUTTON2",
					["sets"] = {
						["default"] = true,
					},
				}, -- [2]
			},
		},
		["Armawolf - Bloodhoof"] = {
			["bindings"] = {
				{
					["type"] = "target",
					["sets"] = {
						["default"] = true,
					},
					["key"] = "BUTTON1",
					["unit"] = "mouseover",
				}, -- [1]
				{
					["type"] = "menu",
					["key"] = "BUTTON2",
					["sets"] = {
						["default"] = true,
					},
				}, -- [2]
			},
		},
		["Necress - Bloodhoof"] = {
			["bindings"] = {
				{
					["type"] = "target",
					["sets"] = {
						["default"] = true,
					},
					["key"] = "BUTTON1",
					["unit"] = "mouseover",
				}, -- [1]
				{
					["type"] = "menu",
					["key"] = "BUTTON2",
					["sets"] = {
						["default"] = true,
					},
				}, -- [2]
			},
		},
		["Rynarch - Draenor"] = {
			["bindings"] = {
				{
					["type"] = "target",
					["sets"] = {
						["default"] = true,
					},
					["key"] = "BUTTON1",
					["unit"] = "mouseover",
				}, -- [1]
				{
					["type"] = "menu",
					["key"] = "BUTTON2",
					["sets"] = {
						["default"] = true,
					},
				}, -- [2]
			},
		},
	},
}
