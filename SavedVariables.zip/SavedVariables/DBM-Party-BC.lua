
DBMPartyBC_AllSavedVars = {
	["Dreadwolf-Wyrmrest Accord"] = {
		["533"] = {
			{
				["SpecWarn36819interruptSWSound"] = 1,
				["SpecWarn44194switchSWNote"] = true,
				["Timer46165nextTColor"] = 4,
				["HealthFrame"] = false,
				["Timer44194cdTColor"] = 1,
				["announce46165spell"] = true,
				["Timer44194nextTColor"] = 6,
				["SpecWarn36819interrupt"] = true,
				["SpecWarn44194switchSWSound"] = 1,
				["Timer36819castTColor"] = 4,
				["Timer44194cd"] = true,
				["SpecWarn44194switch"] = true,
				["Timer36819cast"] = true,
				["Timer44194next"] = true,
				["Timer44194activeTColor"] = 6,
				["Enabled"] = true,
				["announce44224spell"] = true,
				["Timer46165next"] = true,
				["SpecWarn36819interruptSWNote"] = true,
				["Timer44194active"] = true,
			}, -- [1]
		},
		["537"] = {
			{
				["Enabled"] = true,
				["HealthFrame"] = false,
			}, -- [1]
		},
		["572"] = {
			{
				["Enabled"] = true,
				["HealthFrame"] = false,
			}, -- [1]
		},
		["576"] = {
			{
				["HealthFrame"] = false,
				["announce31673spell"] = true,
				["Enabled"] = true,
			}, -- [1]
		},
		["552"] = {
			{
				["Enabled"] = true,
				["announce38539spell"] = true,
				["HealthFrame"] = false,
				["SpecWarn31467dispel"] = false,
				["SpecWarn31467dispelSWSound"] = 1,
				["SpecWarn31467dispelSWNote"] = true,
			}, -- [1]
		},
		["532"] = {
			{
				["SpecWarn17843interrupt2SWNote"] = true,
				["HealthFrame"] = false,
				["SpecWarn44175dispel2SWNote"] = true,
				["SpecWarn44175dispel2SWSound"] = 1,
				["SpecWarn46181interrupt2SWSound"] = 1,
				["announceother44141target2"] = false,
				["Enabled"] = true,
				["SpecWarn17843interrupt2"] = true,
				["announceother13323target"] = true,
				["SpecWarn44175dispel2"] = false,
				["announceother44175target"] = false,
				["SpecWarn46181interrupt2SWNote"] = true,
				["announce27621spell"] = false,
				["SpecWarn46181interrupt2"] = true,
				["announceother46192target2"] = false,
				["announce46195spell"] = true,
				["SpecWarn17843interrupt2SWSound"] = 1,
			}, -- [1]
		},
		["talent1"] = "Blood",
		["573"] = {
			{
				["announce25033spell"] = true,
				["Timer31718target"] = true,
				["announceother31481target"] = true,
				["HealthFrame"] = false,
				["announceother31718target"] = true,
				["Timer31718targetTColor"] = 0,
				["Timer31481targetTColor"] = 0,
				["Enabled"] = true,
				["Timer31481target"] = true,
			}, -- [1]
		},
		["574"] = {
			{
				["Enabled"] = true,
				["Timer35107targetTColor"] = 0,
				["HealthFrame"] = false,
				["SpecWarnej5999switch"] = true,
				["announceother35107target"] = true,
				["SpecWarnej5999switchSWNote"] = true,
				["timer_berserk"] = true,
				["timer_berserkTColor"] = 0,
				["SpecWarnej5999switchSWSound"] = 1,
				["Timer35107target"] = true,
			}, -- [1]
		},
		["544"] = {
			{
				["Enabled"] = true,
				["Timer33547next"] = true,
				["timer_berserk"] = true,
				["HealthFrame"] = false,
				["announce33547spell"] = true,
				["timer_berserkTColor"] = 0,
				["Timer33547nextTColor"] = 0,
			}, -- [1]
		},
		["577"] = {
			{
				["Enabled"] = true,
				["HealthFrame"] = false,
			}, -- [1]
		},
		["548"] = {
			{
				["SpecWarn39367dispel"] = false,
				["SpecWarn39005spell"] = true,
				["SpecWarn39367dispelSWNote"] = true,
				["HealthFrame"] = false,
				["Timer39367target2"] = false,
				["announce36119spell"] = true,
				["SpecWarn39005spellSWSound"] = 2,
				["Timer39367target2TColor"] = 0,
				["SpecWarn39367dispelSWSound"] = 1,
				["Enabled"] = true,
				["SpecWarn39005spellSWNote"] = true,
			}, -- [1]
		},
		["579"] = {
			{
				["Enabled"] = true,
				["HealthFrame"] = false,
			}, -- [1]
		},
		["Ironhand"] = {
			{
				["SpecWarn39194run"] = true,
				["Timer35322activeTColor"] = 0,
				["SpecWarn39194runSWNote"] = true,
				["HealthFrame"] = false,
				["SpecWarn35322dispelSWSound"] = 1,
				["SpecWarn39194runSWSound"] = 4,
				["SpecWarn35322dispelSWNote"] = true,
				["Timer39194activeTColor"] = 0,
				["Timer39194active"] = true,
				["Timer35322active"] = true,
				["announceother35322target"] = true,
				["Enabled"] = true,
				["SpecWarn35322dispel"] = false,
				["announce39194spell"] = true,
			}, -- [1]
		},
		["531"] = {
			{
				["Enabled"] = true,
				["SpecWarnej5085switch3SWSound"] = 1,
				["SpecWarnej5085switch3"] = true,
				["SpecWarnej5085switch3SWNote"] = true,
				["HealthFrame"] = false,
			}, -- [1]
		},
		["555"] = {
			{
				["Enabled"] = true,
				["Timer30923targetTColor"] = 0,
				["HealthFrame"] = false,
				["Timer30923target"] = true,
				["announceother30923target"] = true,
			}, -- [1]
		},
		["550"] = {
			{
				["Enabled"] = true,
				["SpecWarn35759dispelSWSound"] = 1,
				["HealthFrame"] = false,
				["SpecWarn35759dispel"] = false,
				["SpecWarn35759dispelSWNote"] = true,
				["announce36512spell"] = true,
			}, -- [1]
		},
		["535"] = {
			{
				["Enabled"] = true,
				["SpecWarn33919spell"] = true,
				["Timer32361targetTColor"] = 0,
				["SpecWarn33919spellSWSound"] = 2,
				["HealthFrame"] = false,
				["SpecWarn33919spellSWNote"] = true,
				["Timer32361target"] = true,
				["announceother32361target"] = true,
			}, -- [1]
		},
		["570"] = {
			{
				["Enabled"] = true,
				["SpecWarn31991switchSWNote"] = true,
				["HealthFrame"] = false,
				["SpecWarn31991switch"] = false,
				["SpecWarn31991switchSWSound"] = 1,
			}, -- [1]
		},
		["578"] = {
			{
				["Enabled"] = true,
				["HealthFrame"] = false,
			}, -- [1]
		},
		["549"] = {
			{
				["Enabled"] = true,
				["announceother39009target"] = true,
				["HealthFrame"] = false,
				["SpecWarn36175run"] = true,
				["SpecWarn36175runSWSound"] = 4,
				["SpecWarn39013interruptSWSound"] = 1,
				["Timer39009target2"] = false,
				["SpecWarn39013interrupt"] = true,
				["SpecWarn39013interruptSWNote"] = true,
				["SpecWarn36175runSWNote"] = true,
				["Timer39009target2TColor"] = 0,
			}, -- [1]
		},
		["530"] = {
			{
				["Enabled"] = true,
				["SpecWarnej5081switch3"] = true,
				["Timerej5081cd"] = true,
				["HealthFrame"] = false,
				["SpecWarnej5081switch3SWNote"] = true,
				["SpecWarnej5081switch3SWSound"] = 1,
				["Timerej5081cdTColor"] = 1,
			}, -- [1]
		},
		["558"] = {
			{
				["Enabled"] = true,
				["HealthFrame"] = false,
			}, -- [1]
		},
		["551"] = {
			{
				["Enabled"] = true,
				["Timer39019target"] = true,
				["HealthFrame"] = false,
				["announceej5335soon"] = true,
				["announceej5335spell"] = true,
				["announceother39019target"] = true,
				["announceother39017target"] = true,
				["Timer39017target2TColor"] = 0,
				["Timer39017target2"] = false,
				["Timer39019targetTColor"] = 0,
			}, -- [1]
		},
		["575"] = {
			{
				["Enabled"] = true,
				["Timer31534activeTColor"] = 0,
				["Timer31534active"] = true,
				["announceej6001spell"] = true,
				["HealthFrame"] = false,
				["SpecWarn31534reflect"] = false,
				["SpecWarn31534reflectSWNote"] = true,
				["SpecWarn31534reflectSWSound"] = 1,
			}, -- [1]
		},
		["571"] = {
			{
				["Enabled"] = true,
				["SpecWarn38801targetSWNote"] = true,
				["HealthFrame"] = false,
				["SpecWarn38801targetSWSound"] = 1,
				["SpecWarn38801target"] = false,
				["announce34970spell"] = true,
			}, -- [1]
		},
		["556"] = {
			{
				["Enabled"] = true,
				["HealthFrame"] = false,
			}, -- [1]
		},
		["523"] = {
			{
				["Enabled"] = true,
				["HealthFrame"] = false,
			}, -- [1]
		},
		["543"] = {
			{
				["Enabled"] = true,
				["Timer38197cast"] = true,
				["HealthFrame"] = false,
				["announce38197cast"] = true,
				["SpecWarn38197spellSWNote"] = true,
				["announceother38245target"] = true,
				["SpecWarn38197spellSWSound"] = 2,
				["Timer38197castTColor"] = 2,
				["SpecWarn38197spell"] = true,
			}, -- [1]
		},
		["559"] = {
			{
				["Enabled"] = true,
				["SpecWarnej5458switch"] = true,
				["HealthFrame"] = false,
				["SpecWarnej5458switchSWNote"] = true,
				["SpecWarnej5458switchSWSound"] = 1,
			}, -- [1]
		},
		["PT"] = {
			{
				["Enabled"] = true,
				["TimerNextPortalTColor"] = 6,
				["TimerNextPortal"] = true,
				["WarnWavePortal"] = true,
				["WarnWavePortalSoon"] = true,
				["WarnBossPortal"] = true,
				["HealthFrame"] = false,
			}, -- [1]
		},
		["562"] = {
			{
				["Enabled"] = true,
				["announce34727spell"] = true,
				["announce34716spell"] = true,
				["Timer34716activeTColor"] = 0,
				["HealthFrame"] = false,
				["Timer34727next"] = true,
				["Timer34727nextTColor"] = 1,
				["Timer34716active"] = true,
			}, -- [1]
		},
		["547"] = {
			{
				["Enabled"] = true,
				["SpecWarn33711moveaway"] = true,
				["SpecWarn33923runSWSound"] = 4,
				["HealthFrame"] = false,
				["SetIconOnTouchTarget"] = true,
				["Timer33923cast"] = true,
				["SpecWarn33711moveawaySWSound"] = 1,
				["SpecWarn33711moveawaySWNote"] = true,
				["Timer33711targetTColor"] = 0,
				["SpecWarn33923runSWNote"] = true,
				["SpecWarn33923run"] = true,
				["Timer33711target"] = true,
				["Timer33923castTColor"] = 2,
				["announceother33711target"] = true,
			}, -- [1]
		},
		["527"] = {
			{
				["Enabled"] = true,
				["HealthFrame"] = false,
			}, -- [1]
		},
		["557"] = {
			{
				["Enabled"] = true,
				["HealthFrame"] = false,
			}, -- [1]
		},
		["564"] = {
			{
				["Enabled"] = true,
				["HealthFrame"] = false,
			}, -- [1]
		},
		["563"] = {
			{
				["Enabled"] = true,
				["HealthFrame"] = false,
				["announce35159spell"] = true,
				["Timer35159active"] = true,
				["timer_berserkTColor"] = 0,
				["timer_berserk"] = true,
				["Timer35159activeTColor"] = 0,
				["Timer35158activeTColor"] = 0,
				["announce35158spell"] = true,
				["Timer35158active"] = true,
				["announce39096cast"] = true,
			}, -- [1]
		},
		["Gyrokill"] = {
			{
				["Enabled"] = true,
				["Timer35322activeTColor"] = 0,
				["SpecWarn35322dispel"] = false,
				["SpecWarn35322dispelSWNote"] = true,
				["announceother35322target"] = true,
				["HealthFrame"] = false,
				["SpecWarn35322dispelSWSound"] = 1,
				["Timer35322active"] = true,
			}, -- [1]
		},
		["524"] = {
			{
				["HealthFrame"] = false,
				["announce32424spell"] = true,
				["Enabled"] = true,
				["announceother32346target"] = true,
			}, -- [1]
		},
		["553"] = {
			{
				["Enabled"] = true,
				["Timer38592active2TColor"] = 0,
				["SpecWarn38592reflect2SWSound"] = 1,
				["SpecWarn38592reflect2"] = false,
				["HealthFrame"] = false,
				["SpecWarn31458dispelSWSound"] = 1,
				["SpecWarn38592reflect2SWNote"] = true,
				["Timer31458target2TColor"] = 0,
				["Timer38592active2"] = false,
				["SpecWarn31458dispel"] = false,
				["Timer31458target2"] = true,
				["SpecWarn31458dispelSWNote"] = true,
				["announce31458spell"] = true,
			}, -- [1]
		},
		["554"] = {
			{
				["Enabled"] = true,
				["Timer31422active"] = true,
				["announceej5348spell"] = true,
				["HealthFrame"] = false,
				["announce31422spell"] = true,
				["Timer31422activeTColor"] = 0,
			}, -- [1]
		},
		["539"] = {
			{
				["SpecWarn29427interruptSWNote"] = true,
				["SpecWarn38385moveSWSound"] = 1,
				["SpecWarn29427interrupt"] = true,
				["Timer13005targetTColor"] = 0,
				["Timer13005target"] = true,
				["Enabled"] = true,
				["SpecWarn38385moveSWNote"] = true,
				["SpecWarn38385move"] = true,
				["announceother13005target"] = true,
				["SpecWarn29427interruptSWSound"] = 1,
				["HealthFrame"] = false,
			}, -- [1]
		},
		["534"] = {
			{
				["Enabled"] = true,
				["Timer32358active"] = true,
				["Timer32358activeTColor"] = 0,
				["HealthFrame"] = false,
				["SpecWarn32358reflect2SWNote"] = true,
				["SpecWarn32358reflect2SWSound"] = 1,
				["SpecWarn32358reflect2"] = false,
			}, -- [1]
		},
		["569"] = {
			{
				["announceej5930count"] = true,
				["SpecWarn30739spell"] = true,
				["announceej5927count"] = true,
				["Timer30739cd"] = true,
				["HealthFrame"] = false,
				["Timerej5930next"] = true,
				["Timerej5934nextTColor"] = 1,
				["Timer30739cdTColor"] = 2,
				["Enabled"] = true,
				["Timerej5930nextTColor"] = 1,
				["SpecWarn30739spellSWNote"] = true,
				["announceej5934count"] = true,
				["Timerej5927next"] = true,
				["Timerej5934next"] = true,
				["Timerej5927nextTColor"] = 1,
				["SpecWarn30739spellSWSound"] = 2,
			}, -- [1]
		},
		["538"] = {
			{
				["Enabled"] = true,
				["Timer33792target"] = true,
				["Timer33792targetTColor"] = 0,
				["HealthFrame"] = false,
				["announceother33792target"] = true,
			}, -- [1]
		},
		["546"] = {
			{
				["Enabled"] = true,
				["HealthFrame"] = false,
				["Timer33563nextTColor"] = 6,
				["Timer33563next"] = true,
				["announce33563spell"] = true,
			}, -- [1]
		},
		["545"] = {
			{
				["Enabled"] = true,
				["Timer33676active"] = true,
				["announce33676spell"] = true,
				["HealthFrame"] = false,
				["Timer33676nextTColor"] = 3,
				["Timer33676next"] = true,
				["Timer33676activeTColor"] = 0,
			}, -- [1]
		},
		["540"] = {
			{
				["Enabled"] = true,
				["HealthFrame"] = false,
			}, -- [1]
		},
		["565"] = {
			{
				["Enabled"] = true,
				["announceother35280target"] = true,
				["HealthFrame"] = false,
				["Timer35280target"] = true,
				["Timer35280targetTColor"] = 0,
			}, -- [1]
		},
		["560"] = {
			{
				["Enabled"] = true,
				["announceother34661target"] = true,
				["HealthFrame"] = false,
				["Timer34661targetTColor"] = 0,
				["Timer34661target"] = true,
			}, -- [1]
		},
		["529"] = {
			{
				["Enabled"] = true,
				["Timer30689targetTColor"] = 0,
				["SpecWarn30689youSWNote"] = true,
				["SpecWarn30689youSWSound"] = 1,
				["announceother30689target"] = true,
				["Timer30689target"] = true,
				["HealthFrame"] = false,
				["SpecWarn30689you"] = true,
			}, -- [1]
		},
		["542"] = {
			{
				["Timer40321targetTColor"] = 0,
				["HealthFrame"] = false,
				["SpecWarn40184spell"] = true,
				["Timer40184activeTColor"] = 0,
				["announceother40321target"] = true,
				["Timer40321target"] = true,
				["Enabled"] = true,
				["warnStoned"] = false,
				["Timer40184cdTColor"] = 2,
				["Timer40184active"] = true,
				["announce40184spell"] = true,
				["SpecWarn40184spellSWSound"] = 2,
				["announceej5253spell"] = true,
				["Timer40184cd"] = true,
				["Timer40303targetTColor"] = 0,
				["announceother40303target"] = true,
				["Timer40184cast"] = true,
				["Timer40184castTColor"] = 2,
				["SpecWarn40184spellSWNote"] = true,
				["Timer40303target"] = true,
			}, -- [1]
		},
		["568"] = {
			{
				["Enabled"] = true,
				["HealthFrame"] = false,
			}, -- [1]
		},
		["566"] = {
			{
				["Enabled"] = true,
				["HealthFrame"] = false,
				["Timer30496next"] = true,
				["Timer30496nextTColor"] = 3,
				["announce30496spell"] = true,
			}, -- [1]
		},
		["536"] = {
			{
				["Enabled"] = true,
				["HealthFrame"] = false,
			}, -- [1]
		},
		["728"] = {
			{
				["Enabled"] = true,
				["HealthFrame"] = false,
			}, -- [1]
		},
		["541"] = {
			{
				["HealthFrame"] = false,
				["announceej5235spell"] = true,
				["Enabled"] = true,
			}, -- [1]
		},
		["528"] = {
			{
				["Enabled"] = true,
				["SpecWarn37566youSWSound"] = 1,
				["HealthFrame"] = false,
				["Yell37566"] = true,
				["RangeFrame"] = true,
				["Timer37566target"] = true,
				["announceother37566target"] = true,
				["SetIconOnBaneTarget"] = true,
				["Timer37566targetTColor"] = 0,
				["SpecWarn37566you"] = true,
				["SpecWarn37566youSWNote"] = true,
			}, -- [1]
		},
		["561"] = {
			{
				["Enabled"] = true,
				["HealthFrame"] = false,
				["Timer34697targetTColor"] = 0,
				["announceother34697target"] = true,
				["Timer34697target"] = true,
			}, -- [1]
		},
	},
}
