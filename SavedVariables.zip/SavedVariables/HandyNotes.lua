
HandyNotesDB = {
	["profileKeys"] = {
		["Kyndethria - Wyrmrest Accord"] = "Kyndethria - Wyrmrest Accord",
		["Taliowolf - Bloodhoof"] = "Taliowolf - Bloodhoof",
		["Magewolf - Draenor"] = "Magewolf - Draenor",
		["Zekin - Wyrmrest Accord"] = "Zekin - Wyrmrest Accord",
		["Eruswolf - Bloodhoof"] = "Eruswolf - Bloodhoof",
		["Wolfform - Wyrmrest Accord"] = "Wolfform - Wyrmrest Accord",
		["Dreadwolf - Wyrmrest Accord"] = "Dreadwolf - Wyrmrest Accord",
		["Zariimi - Bloodhoof"] = "Zariimi - Bloodhoof",
		["Starrwolf - Bloodhoof"] = "Starrwolf - Bloodhoof",
		["Necress - Bloodhoof"] = "Necress - Bloodhoof",
		["Wolfspirit - Draenor"] = "Wolfspirit - Draenor",
		["Snipewolf - Draenor"] = "Snipewolf - Draenor",
		["Kalixx - Bloodhoof"] = "Kalixx - Bloodhoof",
		["Dreadwolf - Bloodhoof"] = "Dreadwolf - Bloodhoof",
		["Wolfar - Draenor"] = "Wolfar - Draenor",
		["Wolfranger - Draenor"] = "Wolfranger - Draenor",
		["Primalwolf - Bloodhoof"] = "Primalwolf - Bloodhoof",
		["Wolform - Wyrmrest Accord"] = "Wolform - Wyrmrest Accord",
		["Arcanewolf - Bloodhoof"] = "Arcanewolf - Bloodhoof",
		["Nayuka - Bloodhoof"] = "Nayuka - Bloodhoof",
		["Wolfsteel - Draenor"] = "Wolfsteel - Draenor",
		["Rynarch - Wyrmrest Accord"] = "Rynarch - Wyrmrest Accord",
		["Noxwolf - Bloodhoof"] = "Noxwolf - Bloodhoof",
		["Wolfblayde - Draenor"] = "Wolfblayde - Draenor",
		["Zenpaw - Bloodhoof"] = "Zenpaw - Bloodhoof",
		["Kyndeathria - Draenor"] = "Kyndeathria - Draenor",
		["Cowadinn - Bloodhoof"] = "Cowadinn - Bloodhoof",
		["Eiag - Bloodhoof"] = "Eiag - Bloodhoof",
		["Xeonwolf - Bloodhoof"] = "Xeonwolf - Bloodhoof",
		["Wolfform - Draenor"] = "Wolfform - Draenor",
		["Wolfmage - Draenor"] = "Wolfmage - Draenor",
		["Linzzern - Bloodhoof"] = "Linzzern - Bloodhoof",
		["Wolfpet - Wyrmrest Accord"] = "Wolfpet - Wyrmrest Accord",
		["Rhaas - Draenor"] = "Rhaas - Draenor",
		["Wolfglaive - Bloodhoof"] = "Wolfglaive - Bloodhoof",
		["Rynarch - Draenor"] = "Rynarch - Draenor",
	},
	["profiles"] = {
		["Kyndethria - Wyrmrest Accord"] = {
		},
		["Taliowolf - Bloodhoof"] = {
		},
		["Magewolf - Draenor"] = {
		},
		["Zekin - Wyrmrest Accord"] = {
		},
		["Eruswolf - Bloodhoof"] = {
		},
		["Wolfform - Wyrmrest Accord"] = {
		},
		["Dreadwolf - Wyrmrest Accord"] = {
		},
		["Zariimi - Bloodhoof"] = {
		},
		["Starrwolf - Bloodhoof"] = {
		},
		["Necress - Bloodhoof"] = {
		},
		["Wolfspirit - Draenor"] = {
		},
		["Snipewolf - Draenor"] = {
		},
		["Kalixx - Bloodhoof"] = {
		},
		["Dreadwolf - Bloodhoof"] = {
		},
		["Wolfar - Draenor"] = {
		},
		["Wolfranger - Draenor"] = {
		},
		["Primalwolf - Bloodhoof"] = {
		},
		["Wolform - Wyrmrest Accord"] = {
		},
		["Arcanewolf - Bloodhoof"] = {
		},
		["Nayuka - Bloodhoof"] = {
		},
		["Wolfsteel - Draenor"] = {
		},
		["Rynarch - Wyrmrest Accord"] = {
		},
		["Noxwolf - Bloodhoof"] = {
		},
		["Wolfblayde - Draenor"] = {
		},
		["Zenpaw - Bloodhoof"] = {
		},
		["Kyndeathria - Draenor"] = {
		},
		["Cowadinn - Bloodhoof"] = {
		},
		["Eiag - Bloodhoof"] = {
		},
		["Xeonwolf - Bloodhoof"] = {
		},
		["Wolfform - Draenor"] = {
		},
		["Wolfmage - Draenor"] = {
		},
		["Linzzern - Bloodhoof"] = {
		},
		["Wolfpet - Wyrmrest Accord"] = {
		},
		["Rhaas - Draenor"] = {
		},
		["Wolfglaive - Bloodhoof"] = {
		},
		["Rynarch - Draenor"] = {
		},
	},
}
HandyNotes_HandyNotesDB = {
	["profileKeys"] = {
		["Kyndethria - Wyrmrest Accord"] = "Kyndethria - Wyrmrest Accord",
		["Taliowolf - Bloodhoof"] = "Taliowolf - Bloodhoof",
		["Magewolf - Draenor"] = "Magewolf - Draenor",
		["Zekin - Wyrmrest Accord"] = "Zekin - Wyrmrest Accord",
		["Eruswolf - Bloodhoof"] = "Eruswolf - Bloodhoof",
		["Wolfform - Wyrmrest Accord"] = "Wolfform - Wyrmrest Accord",
		["Dreadwolf - Wyrmrest Accord"] = "Dreadwolf - Wyrmrest Accord",
		["Zariimi - Bloodhoof"] = "Zariimi - Bloodhoof",
		["Starrwolf - Bloodhoof"] = "Starrwolf - Bloodhoof",
		["Necress - Bloodhoof"] = "Necress - Bloodhoof",
		["Wolfspirit - Draenor"] = "Wolfspirit - Draenor",
		["Snipewolf - Draenor"] = "Snipewolf - Draenor",
		["Kalixx - Bloodhoof"] = "Kalixx - Bloodhoof",
		["Dreadwolf - Bloodhoof"] = "Dreadwolf - Bloodhoof",
		["Wolfar - Draenor"] = "Wolfar - Draenor",
		["Wolfranger - Draenor"] = "Wolfranger - Draenor",
		["Primalwolf - Bloodhoof"] = "Primalwolf - Bloodhoof",
		["Wolform - Wyrmrest Accord"] = "Wolform - Wyrmrest Accord",
		["Arcanewolf - Bloodhoof"] = "Arcanewolf - Bloodhoof",
		["Nayuka - Bloodhoof"] = "Nayuka - Bloodhoof",
		["Wolfsteel - Draenor"] = "Wolfsteel - Draenor",
		["Rynarch - Wyrmrest Accord"] = "Rynarch - Wyrmrest Accord",
		["Noxwolf - Bloodhoof"] = "Noxwolf - Bloodhoof",
		["Wolfblayde - Draenor"] = "Wolfblayde - Draenor",
		["Zenpaw - Bloodhoof"] = "Zenpaw - Bloodhoof",
		["Kyndeathria - Draenor"] = "Kyndeathria - Draenor",
		["Cowadinn - Bloodhoof"] = "Cowadinn - Bloodhoof",
		["Eiag - Bloodhoof"] = "Eiag - Bloodhoof",
		["Xeonwolf - Bloodhoof"] = "Xeonwolf - Bloodhoof",
		["Wolfform - Draenor"] = "Wolfform - Draenor",
		["Wolfmage - Draenor"] = "Wolfmage - Draenor",
		["Linzzern - Bloodhoof"] = "Linzzern - Bloodhoof",
		["Wolfpet - Wyrmrest Accord"] = "Wolfpet - Wyrmrest Accord",
		["Rhaas - Draenor"] = "Rhaas - Draenor",
		["Wolfglaive - Bloodhoof"] = "Wolfglaive - Bloodhoof",
		["Rynarch - Draenor"] = "Rynarch - Draenor",
	},
	["profiles"] = {
		["Kyndethria - Wyrmrest Accord"] = {
		},
		["Taliowolf - Bloodhoof"] = {
		},
		["Magewolf - Draenor"] = {
		},
		["Zekin - Wyrmrest Accord"] = {
		},
		["Eruswolf - Bloodhoof"] = {
		},
		["Wolfform - Wyrmrest Accord"] = {
		},
		["Dreadwolf - Wyrmrest Accord"] = {
		},
		["Zariimi - Bloodhoof"] = {
		},
		["Starrwolf - Bloodhoof"] = {
		},
		["Necress - Bloodhoof"] = {
		},
		["Wolfspirit - Draenor"] = {
		},
		["Snipewolf - Draenor"] = {
		},
		["Kalixx - Bloodhoof"] = {
		},
		["Dreadwolf - Bloodhoof"] = {
		},
		["Wolfar - Draenor"] = {
		},
		["Wolfranger - Draenor"] = {
		},
		["Primalwolf - Bloodhoof"] = {
		},
		["Wolform - Wyrmrest Accord"] = {
		},
		["Arcanewolf - Bloodhoof"] = {
		},
		["Nayuka - Bloodhoof"] = {
		},
		["Wolfsteel - Draenor"] = {
		},
		["Rynarch - Wyrmrest Accord"] = {
		},
		["Noxwolf - Bloodhoof"] = {
		},
		["Wolfblayde - Draenor"] = {
		},
		["Zenpaw - Bloodhoof"] = {
		},
		["Kyndeathria - Draenor"] = {
		},
		["Cowadinn - Bloodhoof"] = {
		},
		["Eiag - Bloodhoof"] = {
		},
		["Xeonwolf - Bloodhoof"] = {
		},
		["Wolfform - Draenor"] = {
		},
		["Wolfmage - Draenor"] = {
		},
		["Linzzern - Bloodhoof"] = {
		},
		["Wolfpet - Wyrmrest Accord"] = {
		},
		["Rhaas - Draenor"] = {
		},
		["Wolfglaive - Bloodhoof"] = {
		},
		["Rynarch - Draenor"] = {
		},
	},
}
