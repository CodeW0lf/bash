
SLE_ArmoryDB = {
	["EnchantString"] = {
	},
}
