
Postal3DB = {
	["global"] = {
		["BlackBook"] = {
			["alts"] = {
				"Arcanewolf|Bloodhoof|Alliance|88|MAGE", -- [1]
				"Arcanewolf|Bloodhoof|Horde|102|MAGE", -- [2]
				"Dreadwolf|Bloodhoof|Horde|58|DEATHKNIGHT", -- [3]
				"Dreadwolf|Wyrmrest Accord|Alliance|75|DEATHKNIGHT", -- [4]
				"Eruswolf|Bloodhoof|Horde|110|PRIEST", -- [5]
				"Kyndeathria|Draenor|Alliance|98|DEMONHUNTER", -- [6]
				"Kyndethria|Wyrmrest Accord|Alliance|100|DEMONHUNTER", -- [7]
				"Magewolf|Draenor|Alliance|1|MAGE", -- [8]
				"Necress|Bloodhoof|Horde|110|WARLOCK", -- [9]
				"Noxwolf|Bloodhoof|Horde|110|DEATHKNIGHT", -- [10]
				"Primalwolf|Bloodhoof|Horde|100|SHAMAN", -- [11]
				"Rhaas|Draenor|Alliance|23|PALADIN", -- [12]
				"Rynarch|Draenor|Alliance|21|WARRIOR", -- [13]
				"Rynarch|Wyrmrest Accord|Alliance|102|WARRIOR", -- [14]
				"Snipewolf|Draenor|Alliance|1|HUNTER", -- [15]
				"Starrwolf|Bloodhoof|Horde|23|DRUID", -- [16]
				"Taliowolf|Bloodhoof|Horde|110|PALADIN", -- [17]
				"Wolfar|Draenor|Alliance|100|WARRIOR", -- [18]
				"Wolfblayde|Draenor|Alliance|101|WARRIOR", -- [19]
				"Wolfform|Draenor|Alliance|110|DRUID", -- [20]
				"Wolfform|Wyrmrest Accord|Alliance|110|DRUID", -- [21]
				"Wolfglaive|Bloodhoof|Horde|100|DEMONHUNTER", -- [22]
				"Wolfmage|Draenor|Alliance|88|MAGE", -- [23]
				"Wolform|Wyrmrest Accord|Alliance|11|DRUID", -- [24]
				"Wolfpet|Wyrmrest Accord|Alliance|100|HUNTER", -- [25]
				"Wolfranger|Draenor|Alliance|102|HUNTER", -- [26]
				"Wolfspirit|Draenor|Alliance|88|SHAMAN", -- [27]
				"Wolfsteel|Draenor|Alliance|85|ROGUE", -- [28]
				"Xeonwolf|Bloodhoof|Horde|92|ROGUE", -- [29]
				"Zekin|Wyrmrest Accord|Alliance|24|DRUID", -- [30]
				"Zenpaw|Bloodhoof|Horde|107|MONK", -- [31]
			},
		},
	},
	["profileKeys"] = {
		["Kyndethria - Wyrmrest Accord"] = "Kyndethria - Wyrmrest Accord",
		["Taliowolf - Bloodhoof"] = "Taliowolf - Bloodhoof",
		["Magewolf - Draenor"] = "Magewolf - Draenor",
		["Zekin - Wyrmrest Accord"] = "Zekin - Wyrmrest Accord",
		["Wolfpet - Wyrmrest Accord"] = "Wolfpet - Wyrmrest Accord",
		["Wolfform - Wyrmrest Accord"] = "Wolfform - Wyrmrest Accord",
		["Wolfglaive - Bloodhoof"] = "Wolfglaive - Bloodhoof",
		["Rhaas - Draenor"] = "Rhaas - Draenor",
		["Rynarch - Draenor"] = "Rynarch - Draenor",
		["Necress - Bloodhoof"] = "Necress - Bloodhoof",
		["Wolfspirit - Draenor"] = "Wolfspirit - Draenor",
		["Zenpaw - Bloodhoof"] = "Zenpaw - Bloodhoof",
		["Dreadwolf - Bloodhoof"] = "Dreadwolf - Bloodhoof",
		["Wolfar - Draenor"] = "Wolfar - Draenor",
		["Wolfranger - Draenor"] = "Wolfranger - Draenor",
		["Primalwolf - Bloodhoof"] = "Primalwolf - Bloodhoof",
		["Wolform - Wyrmrest Accord"] = "Wolform - Wyrmrest Accord",
		["Arcanewolf - Bloodhoof"] = "Arcanewolf - Bloodhoof",
		["Nayuka - Bloodhoof"] = "Nayuka - Bloodhoof",
		["Wolfsteel - Draenor"] = "Wolfsteel - Draenor",
		["Rynarch - Wyrmrest Accord"] = "Rynarch - Wyrmrest Accord",
		["Xeonwolf - Bloodhoof"] = "Xeonwolf - Bloodhoof",
		["Starrwolf - Bloodhoof"] = "Starrwolf - Bloodhoof",
		["Dreadwolf - Wyrmrest Accord"] = "Dreadwolf - Wyrmrest Accord",
		["Kyndeathria - Draenor"] = "Kyndeathria - Draenor",
		["Zariimi - Bloodhoof"] = "Zariimi - Bloodhoof",
		["Eiag - Bloodhoof"] = "Eiag - Bloodhoof",
		["Wolfblayde - Draenor"] = "Wolfblayde - Draenor",
		["Wolfform - Draenor"] = "Wolfform - Draenor",
		["Wolfmage - Draenor"] = "Wolfmage - Draenor",
		["Linzzern - Bloodhoof"] = "Linzzern - Bloodhoof",
		["Noxwolf - Bloodhoof"] = "Noxwolf - Bloodhoof",
		["Snipewolf - Draenor"] = "Snipewolf - Draenor",
		["Cowadinn - Bloodhoof"] = "Cowadinn - Bloodhoof",
		["Eruswolf - Bloodhoof"] = "Eruswolf - Bloodhoof",
	},
	["profiles"] = {
		["Kyndethria - Wyrmrest Accord"] = {
		},
		["Taliowolf - Bloodhoof"] = {
			["BlackBook"] = {
				["recent"] = {
					"Eruswolf|Bloodhoof|Horde", -- [1]
					"Noxwolf|Bloodhoof|Horde", -- [2]
					"Xeonwolf|Bloodhoof|Horde", -- [3]
					"Arcanewolf|Bloodhoof|Horde", -- [4]
					"Primalwolf|Bloodhoof|Horde", -- [5]
					"Zenpaw|Bloodhoof|Horde", -- [6]
					"Wolfform-Draenor|Bloodhoof|Horde", -- [7]
				},
			},
		},
		["Magewolf - Draenor"] = {
		},
		["Zekin - Wyrmrest Accord"] = {
		},
		["Wolfpet - Wyrmrest Accord"] = {
		},
		["Wolfform - Wyrmrest Accord"] = {
			["BlackBook"] = {
				["recent"] = {
					"Rynarch|Wyrmrest Accord|Alliance", -- [1]
				},
			},
		},
		["Wolfglaive - Bloodhoof"] = {
		},
		["Rhaas - Draenor"] = {
		},
		["Rynarch - Draenor"] = {
			["BlackBook"] = {
				["recent"] = {
					"Wolfform|Draenor|Alliance", -- [1]
				},
			},
		},
		["Necress - Bloodhoof"] = {
			["BlackBook"] = {
				["recent"] = {
					"Eruswolf|Bloodhoof|Horde", -- [1]
					"Taliowolf|Bloodhoof|Horde", -- [2]
					"Noxwolf|Bloodhoof|Horde", -- [3]
					"Xeonwolf|Bloodhoof|Horde", -- [4]
					"Snowfoxx|Bloodhoof|Horde", -- [5]
					"Primalwolf|Bloodhoof|Horde", -- [6]
					"Zenpaw|Bloodhoof|Horde", -- [7]
					"Arcanewolf|Bloodhoof|Horde", -- [8]
				},
			},
		},
		["Wolfspirit - Draenor"] = {
			["BlackBook"] = {
				["recent"] = {
					"Wolfform|Draenor|Alliance", -- [1]
				},
			},
		},
		["Zenpaw - Bloodhoof"] = {
			["BlackBook"] = {
				["recent"] = {
					"Xeonwolf|Bloodhoof|Horde", -- [1]
					"Noxwolf|Bloodhoof|Horde", -- [2]
					"Primalwolf|Bloodhoof|Horde", -- [3]
					"Krysera|Bloodhoof|Horde", -- [4]
				},
			},
		},
		["Dreadwolf - Bloodhoof"] = {
		},
		["Wolfar - Draenor"] = {
		},
		["Wolfranger - Draenor"] = {
			["BlackBook"] = {
				["recent"] = {
					"Wolfform|Draenor|Alliance", -- [1]
					"Noxwolf-Bloodhoof|Draenor|Alliance", -- [2]
					"Zenpaw-Bloodhoof|Draenor|Alliance", -- [3]
					"Primalwolf-Bloodhoof|Draenor|Alliance", -- [4]
				},
			},
		},
		["Primalwolf - Bloodhoof"] = {
			["BlackBook"] = {
				["recent"] = {
					"Noxwolf|Bloodhoof|Horde", -- [1]
					"Taliowolf|Bloodhoof|Horde", -- [2]
					"Xeonwolf|Bloodhoof|Horde", -- [3]
					"Starrwolf|Bloodhoof|Horde", -- [4]
					"Arcanewolf|Bloodhoof|Horde", -- [5]
					"Eruswolf|Bloodhoof|Horde", -- [6]
					"Zenpaw|Bloodhoof|Horde", -- [7]
				},
			},
		},
		["Wolform - Wyrmrest Accord"] = {
		},
		["Arcanewolf - Bloodhoof"] = {
			["BlackBook"] = {
				["recent"] = {
					"Noxwolf|Bloodhoof|Horde", -- [1]
					"Eruswolf|Bloodhoof|Horde", -- [2]
					"Taliowolf|Bloodhoof|Horde", -- [3]
					"Zenpaw|Bloodhoof|Horde", -- [4]
					"Necress|Bloodhoof|Horde", -- [5]
				},
			},
		},
		["Nayuka - Bloodhoof"] = {
		},
		["Wolfsteel - Draenor"] = {
		},
		["Rynarch - Wyrmrest Accord"] = {
		},
		["Xeonwolf - Bloodhoof"] = {
			["BlackBook"] = {
				["recent"] = {
					"Noxwolf|Bloodhoof|Horde", -- [1]
				},
			},
		},
		["Starrwolf - Bloodhoof"] = {
		},
		["Dreadwolf - Wyrmrest Accord"] = {
			["BlackBook"] = {
				["recent"] = {
					"Davás|Wyrmrest Accord|Alliance", -- [1]
				},
			},
		},
		["Kyndeathria - Draenor"] = {
		},
		["Zariimi - Bloodhoof"] = {
		},
		["Eiag - Bloodhoof"] = {
		},
		["Wolfblayde - Draenor"] = {
			["BlackBook"] = {
				["recent"] = {
					"Dreadwolf-Wyrmrest Accord|Draenor|Alliance", -- [1]
				},
			},
		},
		["Wolfform - Draenor"] = {
			["BlackBook"] = {
				["recent"] = {
					"Noxwolf-Bloodhoof|Draenor|Alliance", -- [1]
					"Wolfblayde|Draenor|Alliance", -- [2]
					"Wolfranger|Draenor|Alliance", -- [3]
					"Zenpaw-Bloodhoof|Draenor|Alliance", -- [4]
					"Necress-Bloodhoof|Draenor|Alliance", -- [5]
				},
			},
		},
		["Wolfmage - Draenor"] = {
			["BlackBook"] = {
				["recent"] = {
					"Wolfform|Draenor|Alliance", -- [1]
				},
			},
		},
		["Linzzern - Bloodhoof"] = {
		},
		["Noxwolf - Bloodhoof"] = {
			["BlackBook"] = {
				["recent"] = {
					"Eruswolf|Bloodhoof|Horde", -- [1]
					"Necress|Bloodhoof|Horde", -- [2]
					"Krysuka|Bloodhoof|Horde", -- [3]
					"Xeonwolf|Bloodhoof|Horde", -- [4]
					"Primalwolf|Bloodhoof|Horde", -- [5]
					"Krysetta|Bloodhoof|Horde", -- [6]
					"Arcanewolf|Bloodhoof|Horde", -- [7]
					"Zenpaw|Bloodhoof|Horde", -- [8]
					"Starrwolf|Bloodhoof|Horde", -- [9]
					"Wolfranger-Draenor|Bloodhoof|Horde", -- [10]
					"Wolfform-Draenor|Bloodhoof|Horde", -- [11]
					"Taliowolf|Bloodhoof|Horde", -- [12]
				},
			},
		},
		["Snipewolf - Draenor"] = {
		},
		["Cowadinn - Bloodhoof"] = {
		},
		["Eruswolf - Bloodhoof"] = {
			["BlackBook"] = {
				["recent"] = {
					"Noxwolf|Bloodhoof|Horde", -- [1]
					"Taliowolf|Bloodhoof|Horde", -- [2]
					"Necress|Bloodhoof|Horde", -- [3]
					"Primalwolf|Bloodhoof|Horde", -- [4]
					"Xeonwolf|Bloodhoof|Horde", -- [5]
					"Arcanewolf|Bloodhoof|Horde", -- [6]
					"Föx-Bloodhoof|Bloodhoof|Horde", -- [7]
					"Zenpaw|Bloodhoof|Horde", -- [8]
					"Wolfform-Draenor|Bloodhoof|Horde", -- [9]
				},
			},
		},
	},
}
