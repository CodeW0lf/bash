
PokemonTrainerDB = {
	["namespaces"] = {
		["FrameCombatDisplay"] = {
			["profiles"] = {
				["Default"] = {
					["reorganize_ani"] = false,
					["animate_active"] = false,
				},
			},
		},
		["AuctionSearch"] = {
		},
		["HealBandageButtons"] = {
		},
		["WildPetTooltip"] = {
			["profiles"] = {
				["Default"] = {
					["consolidated"] = true,
					["onlywildpets"] = true,
				},
			},
		},
		["TooltipCombatDisplay"] = {
		},
	},
	["profileKeys"] = {
		["Dreadwolf - Wyrmrest Accord"] = "Default",
		["Rynarch - Wyrmrest Accord"] = "Default",
		["Noxwolf - Bloodhoof"] = "Default",
		["Wolfar - Draenor"] = "Default",
		["Taliowolf - Bloodhoof"] = "Default",
		["Wolfranger - Draenor"] = "Default",
		["Necress - Bloodhoof"] = "Default",
		["Wolfform - Draenor"] = "Default",
		["Wolfspirit - Draenor"] = "Default",
		["Wolfblayde - Draenor"] = "Default",
		["Eruswolf - Bloodhoof"] = "Default",
		["Zenpaw - Bloodhoof"] = "Default",
		["Wolfform - Wyrmrest Accord"] = "Default",
		["Kyndethria - Wyrmrest Accord"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["alpha"] = true,
			["version"] = "7.1.0",
		},
	},
}
PTDevDB = nil
