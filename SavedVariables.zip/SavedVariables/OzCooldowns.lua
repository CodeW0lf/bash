
OzCooldownsDB = {
	["profileKeys"] = {
		["Dreadwolf - Wyrmrest Accord"] = "Dreadwolf - Wyrmrest Accord",
		["Rynarch - Wyrmrest Accord"] = "Rynarch - Wyrmrest Accord",
		["Noxwolf - Bloodhoof"] = "Noxwolf - Bloodhoof",
		["Wolfar - Draenor"] = "Wolfar - Draenor",
		["Taliowolf - Bloodhoof"] = "Taliowolf - Bloodhoof",
		["Wolfranger - Draenor"] = "Wolfranger - Draenor",
		["Necress - Bloodhoof"] = "Necress - Bloodhoof",
		["Wolfform - Draenor"] = "Wolfform - Draenor",
		["Wolfspirit - Draenor"] = "Wolfspirit - Draenor",
		["Wolfblayde - Draenor"] = "Wolfblayde - Draenor",
		["Eruswolf - Bloodhoof"] = "Eruswolf - Bloodhoof",
		["Zenpaw - Bloodhoof"] = "Zenpaw - Bloodhoof",
		["Wolfform - Wyrmrest Accord"] = "Wolfform - Wyrmrest Accord",
		["Kyndethria - Wyrmrest Accord"] = "Kyndethria - Wyrmrest Accord",
	},
	["profiles"] = {
		["Dreadwolf - Wyrmrest Accord"] = {
			["optionsCopied"] = true,
		},
		["Rynarch - Wyrmrest Accord"] = {
			["StatusBarTextureColor"] = {
				["b"] = 0.431372549019608,
				["g"] = 0.611764705882353,
				["r"] = 0.780392156862745,
			},
			["optionsCopied"] = true,
		},
		["Noxwolf - Bloodhoof"] = {
			["optionsCopied"] = true,
		},
		["Wolfar - Draenor"] = {
			["optionsCopied"] = true,
		},
		["Taliowolf - Bloodhoof"] = {
			["optionsCopied"] = true,
		},
		["Wolfranger - Draenor"] = {
			["optionsCopied"] = true,
		},
		["Necress - Bloodhoof"] = {
			["optionsCopied"] = true,
		},
		["Wolfform - Draenor"] = {
			["optionsCopied"] = true,
		},
		["Wolfspirit - Draenor"] = {
			["optionsCopied"] = true,
		},
		["Wolfblayde - Draenor"] = {
			["optionsCopied"] = true,
		},
		["Eruswolf - Bloodhoof"] = {
			["optionsCopied"] = true,
		},
		["Zenpaw - Bloodhoof"] = {
			["optionsCopied"] = true,
		},
		["Wolfform - Wyrmrest Accord"] = {
			["optionsCopied"] = true,
		},
		["Kyndethria - Wyrmrest Accord"] = {
			["optionsCopied"] = true,
		},
	},
}
OzCooldownOptions = nil
