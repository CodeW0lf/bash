
LegionRaresTreasuresDB = {
	["profileKeys"] = {
		["Kyndethria - Wyrmrest Accord"] = "Default",
		["Wolfar - Draenor"] = "Default",
		["Taliowolf - Bloodhoof"] = "Default",
		["Wolfranger - Draenor"] = "Default",
		["Primalwolf - Bloodhoof"] = "Default",
		["Wolform - Wyrmrest Accord"] = "Default",
		["Zekin - Wyrmrest Accord"] = "Default",
		["Eruswolf - Bloodhoof"] = "Default",
		["Wolfform - Wyrmrest Accord"] = "Default",
		["Wolfsteel - Draenor"] = "Default",
		["Dreadwolf - Wyrmrest Accord"] = "Default",
		["Rynarch - Wyrmrest Accord"] = "Default",
		["Noxwolf - Bloodhoof"] = "Default",
		["Rhaas - Draenor"] = "Default",
		["Rynarch - Draenor"] = "Default",
		["Kyndeathria - Draenor"] = "Default",
		["Necress - Bloodhoof"] = "Default",
		["Wolfform - Draenor"] = "Default",
		["Wolfspirit - Draenor"] = "Default",
		["Xeonwolf - Bloodhoof"] = "Default",
		["Wolfblayde - Draenor"] = "Default",
		["Zenpaw - Bloodhoof"] = "Default",
		["Arcanewolf - Bloodhoof"] = "Default",
		["Wolfpet - Wyrmrest Accord"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
