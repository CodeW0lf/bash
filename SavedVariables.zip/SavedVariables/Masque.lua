
MasqueDB = {
	["namespaces"] = {
		["LibDualSpec-1.0"] = {
		},
	},
	["profileKeys"] = {
		["Kyndethria - Wyrmrest Accord"] = "Default",
		["Wolfar - Draenor"] = "Default",
		["Taliowolf - Bloodhoof"] = "Default",
		["Wolfranger - Draenor"] = "Default",
		["Primalwolf - Bloodhoof"] = "Default",
		["Wolform - Wyrmrest Accord"] = "Default",
		["Zekin - Wyrmrest Accord"] = "Default",
		["Arcanewolf - Bloodhoof"] = "Default",
		["Wolfform - Wyrmrest Accord"] = "Default",
		["Wolfsteel - Draenor"] = "Default",
		["Wolfglaive - Bloodhoof"] = "Default",
		["Rynarch - Wyrmrest Accord"] = "Default",
		["Noxwolf - Bloodhoof"] = "Default",
		["Rhaas - Draenor"] = "Default",
		["Rynarch - Draenor"] = "Default",
		["Kyndeathria - Draenor"] = "Default",
		["Wolfblayde - Draenor"] = "Default",
		["Necress - Bloodhoof"] = "Default",
		["Wolfform - Draenor"] = "Default",
		["Wolfspirit - Draenor"] = "Default",
		["Wolfpet - Wyrmrest Accord"] = "Default",
		["Eruswolf - Bloodhoof"] = "Default",
		["Zenpaw - Bloodhoof"] = "Default",
		["Xeonwolf - Bloodhoof"] = "Default",
		["Dreadwolf - Wyrmrest Accord"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["Groups"] = {
				["ElvUI_ActionBars"] = {
					["SkinID"] = "CleanUI Thin",
					["Gloss"] = 0.2,
					["Inherit"] = false,
				},
				["ElvUI_Buffs"] = {
					["Inherit"] = false,
				},
				["ElvUI_Stance Bar"] = {
					["Inherit"] = false,
				},
				["ElvUI_Pet Bar"] = {
					["Inherit"] = false,
					["Gloss"] = 0.3,
					["SkinID"] = "CleanUI Thin",
				},
			},
		},
	},
}
