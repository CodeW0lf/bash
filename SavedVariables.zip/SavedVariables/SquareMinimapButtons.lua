
SquareMinimapButtonOptions = {
	["MoveBlizzard"] = true,
	["BarEnabled"] = false,
	["BarMouseOver"] = true,
	["ButtonsPerRow"] = 12,
	["ButtonSpacing"] = 2,
	["IconSize"] = 27,
}
