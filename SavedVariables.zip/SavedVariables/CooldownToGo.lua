
CooldownToGoDB = {
	["namespaces"] = {
		["LibDualSpec-1.0"] = {
		},
	},
	["profileKeys"] = {
		["Kyndethria - Wyrmrest Accord"] = "Kyndethria - Wyrmrest Accord",
		["Taliowolf - Bloodhoof"] = "Taliowolf - Bloodhoof",
		["Wolfblayde - Draenor"] = "Wolfblayde - Draenor",
		["Zekin - Wyrmrest Accord"] = "Zekin - Wyrmrest Accord",
		["Eruswolf - Bloodhoof"] = "Eruswolf - Bloodhoof",
		["Wolfform - Wyrmrest Accord"] = "Wolfform - Wyrmrest Accord",
		["Cowadinn - Bloodhoof"] = "Cowadinn - Bloodhoof",
		["Zariimi - Bloodhoof"] = "Zariimi - Bloodhoof",
		["Starrwolf - Bloodhoof"] = "Starrwolf - Bloodhoof",
		["Foxymonk - Bloodhoof"] = "Foxymonk - Bloodhoof",
		["Armawolf - Bloodhoof"] = "Armawolf - Bloodhoof",
		["Wolfspirit - Draenor"] = "Wolfspirit - Draenor",
		["Foxymonk - Draenor"] = "Foxymonk - Draenor",
		["Snipewolf - Draenor"] = "Snipewolf - Draenor",
		["Kalixx - Bloodhoof"] = "Kalixx - Bloodhoof",
		["Dreadwolf - Bloodhoof"] = "Dreadwolf - Bloodhoof",
		["Ceryk - Draenor"] = "Ceryk - Draenor",
		["Wolfar - Draenor"] = "Wolfar - Draenor",
		["Zenpaw - Bloodhoof"] = "Zenpaw - Bloodhoof",
		["Wolfcaster - Draenor"] = "Wolfcaster - Draenor",
		["Wolfranger - Draenor"] = "Wolfranger - Draenor",
		["Primalwolf - Bloodhoof"] = "Primalwolf - Bloodhoof",
		["Kyonii - Draenor"] = "Kyonii - Draenor",
		["Wolform - Wyrmrest Accord"] = "Wolform - Wyrmrest Accord",
		["Dreadwolf - Wyrmrest Accord"] = "Dreadwolf - Wyrmrest Accord",
		["Arcanewolf - Bloodhoof"] = "Arcanewolf - Bloodhoof",
		["Nayuka - Bloodhoof"] = "Nayuka - Bloodhoof",
		["Lightpaw - Draenor"] = "Lightpaw - Draenor",
		["Wolfsteel - Draenor"] = "Wolfsteel - Draenor",
		["Necress - Bloodhoof"] = "Necress - Bloodhoof",
		["Rynarch - Wyrmrest Accord"] = "Rynarch - Wyrmrest Accord",
		["Xeonwolf - Bloodhoof"] = "Xeonwolf - Bloodhoof",
		["Magewolf - Draenor"] = "Magewolf - Draenor",
		["Zorazz - Bloodhoof"] = "Zorazz - Bloodhoof",
		["Kyndeathria - Draenor"] = "Kyndeathria - Draenor",
		["Noxwolf - Bloodhoof"] = "Noxwolf - Bloodhoof",
		["Eiag - Bloodhoof"] = "Eiag - Bloodhoof",
		["Dreadwolf - Draenor"] = "Dreadwolf - Draenor",
		["Wolfform - Draenor"] = "Wolfform - Draenor",
		["Wolfmage - Draenor"] = "Wolfmage - Draenor",
		["Linzzern - Bloodhoof"] = "Linzzern - Bloodhoof",
		["Wolfglaive - Bloodhoof"] = "Wolfglaive - Bloodhoof",
		["Wolfpet - Wyrmrest Accord"] = "Wolfpet - Wyrmrest Accord",
		["Rynarch - Draenor"] = "Rynarch - Draenor",
		["Rhaas - Draenor"] = "Rhaas - Draenor",
	},
	["profiles"] = {
		["Kyndethria - Wyrmrest Accord"] = {
			["locked"] = true,
		},
		["Taliowolf - Bloodhoof"] = {
			["locked"] = true,
			["x"] = -17.8331317901611,
			["y"] = 92.6668319702148,
			["warnSound"] = false,
		},
		["Wolfblayde - Draenor"] = {
			["locked"] = true,
		},
		["Zekin - Wyrmrest Accord"] = {
			["locked"] = true,
		},
		["Eruswolf - Bloodhoof"] = {
			["locked"] = true,
			["warnSound"] = false,
		},
		["Wolfform - Wyrmrest Accord"] = {
			["locked"] = true,
		},
		["Cowadinn - Bloodhoof"] = {
			["locked"] = true,
			["y"] = 99.9999694824219,
		},
		["Zariimi - Bloodhoof"] = {
			["locked"] = true,
		},
		["Starrwolf - Bloodhoof"] = {
			["locked"] = true,
		},
		["Foxymonk - Bloodhoof"] = {
			["locked"] = true,
			["y"] = 99.9999694824219,
		},
		["Armawolf - Bloodhoof"] = {
			["locked"] = true,
			["x"] = -1.99894142150879,
			["y"] = 141.999877929688,
		},
		["Wolfspirit - Draenor"] = {
			["locked"] = true,
			["warnSound"] = false,
		},
		["Foxymonk - Draenor"] = {
			["locked"] = true,
		},
		["Snipewolf - Draenor"] = {
			["locked"] = true,
			["x"] = -4.00004196166992,
			["y"] = 106.000030517578,
		},
		["Kalixx - Bloodhoof"] = {
			["locked"] = true,
			["x"] = -17.9998531341553,
			["y"] = 110.999946594238,
			["warnSound"] = false,
		},
		["Dreadwolf - Bloodhoof"] = {
			["locked"] = true,
		},
		["Ceryk - Draenor"] = {
			["locked"] = true,
		},
		["Wolfar - Draenor"] = {
			["locked"] = true,
		},
		["Zenpaw - Bloodhoof"] = {
			["locked"] = true,
		},
		["Wolfcaster - Draenor"] = {
			["locked"] = true,
		},
		["Wolfranger - Draenor"] = {
			["locked"] = true,
			["x"] = -6.99993848800659,
			["y"] = 104.000007629395,
			["warnSound"] = false,
		},
		["Primalwolf - Bloodhoof"] = {
			["locked"] = true,
			["x"] = -2.00015592575073,
			["y"] = 100.000038146973,
			["warnSound"] = false,
		},
		["Kyonii - Draenor"] = {
			["locked"] = true,
			["x"] = -7.99994945526123,
			["y"] = 108.000053405762,
		},
		["Wolform - Wyrmrest Accord"] = {
			["locked"] = true,
		},
		["Dreadwolf - Wyrmrest Accord"] = {
			["locked"] = true,
		},
		["Arcanewolf - Bloodhoof"] = {
			["locked"] = true,
		},
		["Nayuka - Bloodhoof"] = {
			["locked"] = true,
		},
		["Lightpaw - Draenor"] = {
			["locked"] = true,
		},
		["Wolfsteel - Draenor"] = {
			["locked"] = true,
		},
		["Necress - Bloodhoof"] = {
			["fontOutline"] = "OUTLINE",
			["locked"] = true,
			["warnSound"] = false,
			["y"] = 103.000144958496,
			["x"] = -15.999831199646,
		},
		["Rynarch - Wyrmrest Accord"] = {
			["locked"] = true,
		},
		["Xeonwolf - Bloodhoof"] = {
			["locked"] = true,
			["warnSound"] = false,
			["y"] = 99.9999694824219,
		},
		["Magewolf - Draenor"] = {
			["locked"] = true,
			["x"] = -8.0000171661377,
			["y"] = 122.999946594238,
		},
		["Zorazz - Bloodhoof"] = {
			["locked"] = true,
		},
		["Kyndeathria - Draenor"] = {
			["locked"] = true,
		},
		["Noxwolf - Bloodhoof"] = {
			["y"] = 110.333351135254,
			["font"] = "Bui Prototype",
			["locked"] = true,
			["x"] = -0.83319365978241,
			["warnSound"] = false,
		},
		["Eiag - Bloodhoof"] = {
			["locked"] = true,
		},
		["Dreadwolf - Draenor"] = {
			["locked"] = true,
		},
		["Wolfform - Draenor"] = {
			["locked"] = true,
			["x"] = -16.9999084472656,
			["y"] = 115.000137329102,
		},
		["Wolfmage - Draenor"] = {
			["locked"] = true,
			["x"] = -15.999831199646,
			["warnSound"] = false,
			["y"] = 105.999969482422,
		},
		["Linzzern - Bloodhoof"] = {
			["locked"] = true,
		},
		["Wolfglaive - Bloodhoof"] = {
			["locked"] = true,
		},
		["Wolfpet - Wyrmrest Accord"] = {
			["locked"] = true,
		},
		["Rynarch - Draenor"] = {
			["locked"] = true,
		},
		["Rhaas - Draenor"] = {
			["locked"] = true,
			["y"] = 99.9999771118164,
		},
	},
}
