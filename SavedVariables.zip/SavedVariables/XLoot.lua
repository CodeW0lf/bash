
XLootADB = {
	["namespaces"] = {
		["Group"] = {
			["profiles"] = {
				["Default"] = {
					["roll_anchor"] = {
						["visible"] = false,
						["x"] = 97.4801177978516,
						["y"] = 775.800170898438,
					},
					["alert_anchor"] = {
						["visible"] = false,
					},
				},
			},
		},
		["Frame"] = {
		},
		["Monitor"] = {
			["profiles"] = {
				["Default"] = {
					["threshold_own"] = 1,
					["show_coin"] = true,
					["anchor"] = {
						["visible"] = false,
						["x"] = 1439.98612592405,
						["scale"] = 1.2,
						["y"] = 201.05666156971,
					},
				},
			},
		},
		["Master"] = {
		},
	},
	["profileKeys"] = {
		["Kyndethria - Wyrmrest Accord"] = "Default",
		["Taliowolf - Bloodhoof"] = "Default",
		["Wolfblayde - Draenor"] = "Default",
		["Zekin - Wyrmrest Accord"] = "Default",
		["Wolfpet - Wyrmrest Accord"] = "Default",
		["Wolfform - Wyrmrest Accord"] = "Default",
		["Cowadinn - Bloodhoof"] = "Default",
		["Rhaas - Draenor"] = "Default",
		["Rynarch - Draenor"] = "Default",
		["Necress - Bloodhoof"] = "Default",
		["Wolfspirit - Draenor"] = "Default",
		["Snipewolf - Draenor"] = "Default",
		["Dreadwolf - Bloodhoof"] = "Default",
		["Wolfar - Draenor"] = "Default",
		["Wolfranger - Draenor"] = "Default",
		["Primalwolf - Bloodhoof"] = "Default",
		["Wolform - Wyrmrest Accord"] = "Default",
		["Arcanewolf - Bloodhoof"] = "Default",
		["Nayuka - Bloodhoof"] = "Default",
		["Wolfsteel - Draenor"] = "Default",
		["Rynarch - Wyrmrest Accord"] = "Default",
		["Noxwolf - Bloodhoof"] = "Default",
		["Starrwolf - Bloodhoof"] = "Default",
		["Dreadwolf - Wyrmrest Accord"] = "Default",
		["Kyndeathria - Draenor"] = "Default",
		["Zariimi - Bloodhoof"] = "Default",
		["Eiag - Bloodhoof"] = "Default",
		["Magewolf - Draenor"] = "Default",
		["Wolfform - Draenor"] = "Default",
		["Wolfmage - Draenor"] = "Default",
		["Linzzern - Bloodhoof"] = "Default",
		["Xeonwolf - Bloodhoof"] = "Default",
		["Zenpaw - Bloodhoof"] = "Default",
		["Wolfglaive - Bloodhoof"] = "Default",
		["Eruswolf - Bloodhoof"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["skin_anchors"] = true,
			["skin"] = "Renaitre: Fade",
		},
	},
}
